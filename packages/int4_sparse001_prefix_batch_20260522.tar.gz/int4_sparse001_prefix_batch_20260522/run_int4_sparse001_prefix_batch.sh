#!/bin/bash
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$REPO_ROOT"

ENV_NAME="${ENV_NAME:-mezo-rtnclip-int4}"
SOURCE_ENV="${SOURCE_ENV:-ciao}"
OUTPUT_ROOT="${OUTPUT_ROOT:-outputs/int4_sparse001_prefix_batch_20260522}"

if [[ -f "$HOME/miniconda3/etc/profile.d/conda.sh" ]]; then
  source "$HOME/miniconda3/etc/profile.d/conda.sh"
elif [[ -f "$HOME/.conda/etc/profile.d/conda.sh" ]]; then
  source "$HOME/.conda/etc/profile.d/conda.sh"
else
  echo "Could not find conda.sh" >&2
  exit 1
fi

if conda env list | awk '{print $1}' | grep -Fxq "$ENV_NAME"; then
  echo "Conda env $ENV_NAME already exists; skipping creation."
else
  echo "Creating conda env $ENV_NAME by cloning $SOURCE_ENV"
  conda create -y -n "$ENV_NAME" --clone "$SOURCE_ENV"
fi

conda activate "$ENV_NAME"
python -m py_compile tools/rtnclip_roberta_sst5_batch.py

export CONDA_ENV="$ENV_NAME"
export OUTPUT_ROOT="$OUTPUT_ROOT"
export REPO_ROOT="$REPO_ROOT"
export DATALOADER_SHUFFLE=True

bash scripts/submit_int4_sparse001_prefix_batch.sh
