#!/bin/bash
set -euo pipefail

ACCOUNT="${ACCOUNT:-}"
PARTITION="${PARTITION:-}"
TIME="${TIME:-48:00:00}"
GPUS="${GPUS:-1}"
GPU_TYPE="${GPU_TYPE:-H100}"
CONDA_ENV="${CONDA_ENV:-ciao}"
OUTPUT_ROOT="${OUTPUT_ROOT:-outputs/int4_sparse001_prefix_batch_20260522}"
REPO_ROOT="${REPO_ROOT:-$(pwd)}"

mkdir -p "$OUTPUT_ROOT/slurm_logs" "$OUTPUT_ROOT/jobs"
args=(
  --job-name=int4_sparse001_prefix
  --nodes=1
  --ntasks=1
  --cpus-per-task=8
  --mem=96G
  --time="$TIME"
  --gres="gpu:${GPU_TYPE}:${GPUS}"
  --array=0-5
  --output="$OUTPUT_ROOT/slurm_logs/%x_%A_%a.out"
  --export=ALL,OUTPUT_ROOT="$OUTPUT_ROOT",REPO_ROOT="$REPO_ROOT",CONDA_ENV="$CONDA_ENV",GPU_TYPE="$GPU_TYPE"
)
if [[ -n "$ACCOUNT" ]]; then args+=(--account="$ACCOUNT"); fi
if [[ -n "$PARTITION" ]]; then args+=(--partition="$PARTITION"); fi

sbatch "${args[@]}" slurm/int4_sparse001_prefix_lane.sbatch | tee -a "$OUTPUT_ROOT/jobs/job_ids.txt"
