# INT4 Full-Data h-star Summary

Selector: `simple2pt_corrected`; Delta = RTNClip scale RMS / sqrt(6), G = clean32 absG median over 1e-4/3e-4/1e-3, L = clean32 q90.

| dataset | direction | hstar_cont | nearest | G | L | Delta | d_trainable |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| sst-2 | sparse | 0.0016413 | 1p5e-3 | 0.782891 | 5.04292e-05 | 0.00309595 | 4460434 |
| sst-5 | sparse | 0.0021726 | 2e-3 | 2.98879 | 0.000109872 | 0.00309595 | 4460468 |
| rte | sparse | 0.000834356 | 1e-3 | 0.73805 | 0.000183967 | 0.00309595 | 4460434 |
| mnli | sparse | 0.00168202 | 1p5e-3 | 2.42129 | 0.000148505 | 0.00309595 | 4460445 |
| trec | sparse | 0.00271768 | 3e-3 | 3.78805 | 8.89961e-05 | 0.00309595 | 4460479 |
