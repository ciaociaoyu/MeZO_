# INT4 sparse p=0.01 + prefix full-data batch

Run from repo root after unpacking:

```bash
PARTITION=gpu_p GPU_TYPE=H100 ./run_int4_sparse001_prefix_batch.sh
```

The script creates conda env `mezo-rtnclip-int4` by cloning `SOURCE_ENV` (default `ciao`) if it does not already exist. If the env already exists, creation is skipped.

Output root: `outputs/int4_sparse001_prefix_batch_20260522`

Runs:
- Sparse INT4 p=0.01 highest_abs unscaled, h policies: `1e-5`, `1e-3`, `hstar_ours` from `hstar_sparse_p0p01/hstar_full_data_summary.csv`.
- Prefix INT4-base Prefix-MeZO, h policies: `1e-5`, `1e-3`, `0.1`.

Common settings:
- RoBERTa-large
- datasets: SST-2, SST-5, RTE, MNLI, TREC
- full data, seed/data_seed 16, bs64, RandomSampler
- INT4 G128 RTNClip shared-grid fake quantized base forward
- FP16 master update
- max_steps 20000, eval/checkpoint every 1000
- 6 H100 lanes

Prefix note:
- Prefix uses random prefix init. The real-activation initializer is disabled because it triggers CUDA index asserts with the current tokenizer/model stack.
- Prefix h=0.1 is selected from prior SST-5 full-data prefix probe: `outputs/rtnclip_int4_adapter_nmse_probe_20260522_dirs32/summary.csv`.
