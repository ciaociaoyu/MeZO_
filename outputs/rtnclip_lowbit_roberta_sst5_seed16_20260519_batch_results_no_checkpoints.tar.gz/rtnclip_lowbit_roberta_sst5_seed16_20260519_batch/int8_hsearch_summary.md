# INT8 RTNClip H-Search Summary

| h | status | steps | best_acc | last_acc | best_loss | last_loss | run_dir |
| --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| 1e-2 | complete | 20000 | 0.2716627634660422 | 0.27049180327868855 | 1.5978689439402811 | 1.6176540544496487 | `/scratch/jy03364/MeZO_/outputs/rtnclip_lowbit_roberta_sst5_seed16_20260519_batch/int8_hsearch/int8_g128_rtnclip_k1_h1e-2_seed16_bs64_ckpt1k` |
| 1e-3 | complete | 20000 | 0.4765807962529274 | 0.4765807962529274 | 1.2940505159543325 | 1.2940505159543325 | `/scratch/jy03364/MeZO_/outputs/rtnclip_lowbit_roberta_sst5_seed16_20260519_batch/int8_hsearch/int8_g128_rtnclip_k1_h1e-3_seed16_bs64_ckpt1k` |
| 1e-4 | complete | 20000 | 0.45784543325526933 | 0.45784543325526933 | 1.2812751573477752 | 1.2812751573477752 | `/scratch/jy03364/MeZO_/outputs/rtnclip_lowbit_roberta_sst5_seed16_20260519_batch/int8_hsearch/int8_g128_rtnclip_k1_h1e-4_seed16_bs64_ckpt1k` |
| 1e-5 | complete | 20000 | 0.3395784543325527 | 0.24824355971896955 | 1.550593713407494 | 1.6192138100117095 | `/scratch/jy03364/MeZO_/outputs/rtnclip_lowbit_roberta_sst5_seed16_20260519_batch/int8_hsearch/int8_g128_rtnclip_k1_h1e-5_seed16_bs64_ckpt1k` |
| 1p5e-3 | complete | 20000 | 0.45784543325526933 | 0.45784543325526933 | 1.3665013905152226 | 1.3665013905152226 | `/scratch/jy03364/MeZO_/outputs/rtnclip_lowbit_roberta_sst5_seed16_20260519_batch/int8_hsearch/int8_g128_rtnclip_k1_h1p5e-3_seed16_bs64_ckpt1k` |
| 2e-3 | complete | 20000 | 0.4613583138173302 | 0.4613583138173302 | 1.4025816012880563 | 1.4025816012880563 | `/scratch/jy03364/MeZO_/outputs/rtnclip_lowbit_roberta_sst5_seed16_20260519_batch/int8_hsearch/int8_g128_rtnclip_k1_h2e-3_seed16_bs64_ckpt1k` |
| 3e-3 | complete | 20000 | 0.36533957845433257 | 0.3594847775175644 | 1.4986163458723654 | 1.4986163458723654 | `/scratch/jy03364/MeZO_/outputs/rtnclip_lowbit_roberta_sst5_seed16_20260519_batch/int8_hsearch/int8_g128_rtnclip_k1_h3e-3_seed16_bs64_ckpt1k` |
| 3e-4 | complete | 20000 | 0.4648711943793911 | 0.4648711943793911 | 1.3259820513758782 | 1.3259820513758782 | `/scratch/jy03364/MeZO_/outputs/rtnclip_lowbit_roberta_sst5_seed16_20260519_batch/int8_hsearch/int8_g128_rtnclip_k1_h3e-4_seed16_bs64_ckpt1k` |
| 3e-5 | complete | 20000 | 0.4672131147540984 | 0.4613583138173302 | 1.3477362961065573 | 1.3477362961065573 | `/scratch/jy03364/MeZO_/outputs/rtnclip_lowbit_roberta_sst5_seed16_20260519_batch/int8_hsearch/int8_g128_rtnclip_k1_h3e-5_seed16_bs64_ckpt1k` |
| 4e-3 | complete | 20000 | 0.34894613583138173 | 0.34894613583138173 | 1.525665068793911 | 1.525665068793911 | `/scratch/jy03364/MeZO_/outputs/rtnclip_lowbit_roberta_sst5_seed16_20260519_batch/int8_hsearch/int8_g128_rtnclip_k1_h4e-3_seed16_bs64_ckpt1k` |
| 5e-3 | complete | 20000 | 0.27634660421545665 | 0.275175644028103 | 1.5791884697014051 | 1.5798471348067915 | `/scratch/jy03364/MeZO_/outputs/rtnclip_lowbit_roberta_sst5_seed16_20260519_batch/int8_hsearch/int8_g128_rtnclip_k1_h5e-3_seed16_bs64_ckpt1k` |
