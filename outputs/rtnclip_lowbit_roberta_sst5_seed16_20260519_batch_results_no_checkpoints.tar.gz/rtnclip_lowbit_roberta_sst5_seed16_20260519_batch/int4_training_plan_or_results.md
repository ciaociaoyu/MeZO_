# INT4 Training Plan

INT4 probe verdict is `viable_window`. Candidate h values for a later approved training stage: `1e-3`, `1e-5`, `5e-3`, `1e-2`.
