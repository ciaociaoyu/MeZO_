# Scheduler Jobs

## dry_run_table.txt

```
lane_id gpu_pref num_runs total_steps run_names
      0 H100            2       40000 int8_g128_rtnclip_k1_h1e-5_seed16_bs64_ckpt1k int8_g128_rtnclip_k1_h1e-3_seed16_bs64_ckpt1k
      1 H100            2       40000 int8_g128_rtnclip_k1_h3e-5_seed16_bs64_ckpt1k int8_g128_rtnclip_k1_h1p5e-3_seed16_bs64_ckpt1k
      2 A100            2       40000 int8_g128_rtnclip_k1_h1e-4_seed16_bs64_ckpt1k int8_g128_rtnclip_k1_h2e-3_seed16_bs64_ckpt1k
      3 A100            2       40000 int8_g128_rtnclip_k1_h3e-4_seed16_bs64_ckpt1k int8_g128_rtnclip_k1_h3e-3_seed16_bs64_ckpt1k
      4 A100            2       40000 int8_g128_rtnclip_k1_h4e-3_seed16_bs64_ckpt1k int8_g128_rtnclip_k1_h5e-3_seed16_bs64_ckpt1k
      5 A100            1       20000 int8_g128_rtnclip_k1_h1e-2_seed16_bs64_ckpt1k
```

## job_ids.txt

```
submitted_at=2026-05-19T18:46:02-04:00
exp_root=/scratch/jy03364/MeZO_/outputs/rtnclip_lowbit_roberta_sst5_seed16_20260519_batch
partition=gpu_p
max_active_lanes=6
squeue_before=             JOBID PARTITION                           NAME    STATE       TIME TIME_LIMI  NODES NODELIST(REASON);          45463225     gpu_p                       interact  RUNNING    1:21:11  12:00:00      1 ra7-1;          45462518     gpu_p                       interact  RUNNING    1:57:28  12:00:00      1 ra7-1;
sinfo_before=PARTITION            AVAIL      TIMELIMIT  NODES      NODELIST;scavenge_p           up         4:00:00    128        a1-[1-22],a5-[15-21],b5-[1-17,19-22],b7-[5-16],c2-1,c5-24,d1-[1-11],d2-[1-12],d4-[13-24],d5-[7,23-24],e2-[1-4],ra1-[1-7,13,15-19,22],ra3-[3,7,10-11],rb7-[2-3,6-7];batch                up         7-00:00:00 326        a2-[1-24],a3-[1,5-22],a4-[1-24],a5-[1-13],b1-[1-23],b2-[21-24],b3-[21,23-24],c1-[1-10,12-24],c4-[1-15,17-19,21],c5-[1-21],d1-[12-16],d2-[15-24],d4-[1-10],d5-[1-6,8-14,16,18-22],e1-[1-16],e2-[5-16],e3-[1-16],ra2-[1-24],ra4-6,ra5-[9-12],ra6-[1-24],ra7-[9-12],ra8-[9-12],rb7-[8-11];batch_30d            up         30-00:00:0 326        a2-[1-24],a3-[1,5-22],a4-[1-24],a5-[1-13],b1-[1-23],b2-[21-24],b3-[21,23-24],c1-[1-10,12-24],c4-[1-15,17-19,21],c5-[1-21],d1-[12-16],d2-[15-24],d4-[1-10],d5-[1-6,8-14,16,18-22],e1-[1-16],e2-[5-16],e3-[1-16],ra2-[1-24],ra4-6,ra5-[9-12],ra6-[1-24],ra7-[9-12],ra8-[9-12],rb7-[8-11];gpu_30d_p            up         30-00:00:0 19         a1-[23-24],b6-[1-4],b7-[1-4],c5-[22-23],ra5-[1-4],ra7-[5-7];gpu_p                up         7-00:00:00 43         a1-[23-24],b6-[1-4],b7-[1-4],b8-[1-4],c5-[22-23],ra4-[1-2],ra5-[1-8],ra7-[1-8],ra8-[1-8],rb7-4;highmem_30d_p        up         30-00:00:0 24         b5-[23-24],b6-[5-16],d1-[17-24],d4-[11-12];highmem_p            up         7-00:00:00 24         b5-[23-24],b6-[5-16],d1-[17-24],d4-[11-12];hugemem_30d_p        up         30-00:00:0 5          a3-[23-24],ra4-[3-5];hugemem_p            up         7-00:00:00 5          a3-[23-24],ra4-[3-5];inter_p              up         2-00:00:00 7          a3-[2-4],c4-[16,20],d5-[15,17];bergman_p            up         30-00:00:0 4          d1-[5-6],ra1-[15-16];iai_B200_p           up         2-00:00:00 1          e4-1;iai_L40_p            up         30-00:00:0 1          rb7-4;
lane0_preferred_H100_job=45464034
lane0_preferred_pending_after_300s=45464034; cancelling and submitting L4 fallback
lane0_fallback_L4_job=45464107
lane1_preferred_H100_job=45464108
lane1_preferred_pending_after_300s=45464108; cancelling and submitting L4 fallback
lane1_fallback_L4_job=45464143
lane2_preferred_A100_job=45464144
lane2_preferred_pending_after_300s=45464144; cancelling and submitting L4 fallback
lane2_fallback_L4_job=45464174
lane3_preferred_A100_job=45464175
lane3_preferred_pending_after_300s=45464175; cancelling and submitting L4 fallback
lane3_fallback_L4_job=45464213
lane4_preferred_A100_job=45464214
lane4_preferred_pending_after_300s=45464214; cancelling and submitting L4 fallback
lane4_fallback_L4_job=45464245
lane5_preferred_A100_job=45464246
lane5_preferred_pending_after_300s=45464246; cancelling and submitting L4 fallback
lane5_fallback_L4_job=45464256
```

