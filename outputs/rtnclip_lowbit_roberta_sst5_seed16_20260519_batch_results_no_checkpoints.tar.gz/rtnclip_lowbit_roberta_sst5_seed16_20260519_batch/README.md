# RTNClip Low-Bit RoBERTa SST-5 Seed16

Official dense RoBERTa-large / SST-5 low-bit batch using G128 groupwise RTNClip
fake quantization, shared-grid plus/minus probes, fresh perturbed integer codes,
and FP16 master updates. This is not GPTQ and does not run sparse, residual-grid,
direct INT update, LoRA, RTE/MNLI/OPT/Mistral, NF4, AWQ, or HQQ.
