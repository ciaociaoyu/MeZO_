# RTNClip Low-Bit Batch Report

Output root: `/scratch/jy03364/MeZO_/outputs/rtnclip_lowbit_roberta_sst5_seed16_20260519_batch`

Smoke checks passed: yes
INT4 probe verdict: `viable_window`; selected_h=`5e-3`, bad_small=`1e-5`, bad_large=`1e-2`.
INT4 full training: not launched in this batch; plan written to `int4_training_plan_or_results.md`.

## INT8 H-Search Status

| h | status | steps | last_eval_acc | run_dir |
| --- | --- | ---: | ---: | --- |
| 1e-5 | running | 1040 | 0.3079625292740047 | `/scratch/jy03364/MeZO_/outputs/rtnclip_lowbit_roberta_sst5_seed16_20260519_batch/int8_hsearch/int8_g128_rtnclip_k1_h1e-5_seed16_bs64_ckpt1k` |
| 1e-3 | pending | 0 |  | `/scratch/jy03364/MeZO_/outputs/rtnclip_lowbit_roberta_sst5_seed16_20260519_batch/int8_hsearch/int8_g128_rtnclip_k1_h1e-3_seed16_bs64_ckpt1k` |
| 3e-5 | running | 900 |  | `/scratch/jy03364/MeZO_/outputs/rtnclip_lowbit_roberta_sst5_seed16_20260519_batch/int8_hsearch/int8_g128_rtnclip_k1_h3e-5_seed16_bs64_ckpt1k` |
| 1p5e-3 | pending | 0 |  | `/scratch/jy03364/MeZO_/outputs/rtnclip_lowbit_roberta_sst5_seed16_20260519_batch/int8_hsearch/int8_g128_rtnclip_k1_h1p5e-3_seed16_bs64_ckpt1k` |
| 1e-4 | running | 605 |  | `/scratch/jy03364/MeZO_/outputs/rtnclip_lowbit_roberta_sst5_seed16_20260519_batch/int8_hsearch/int8_g128_rtnclip_k1_h1e-4_seed16_bs64_ckpt1k` |
| 2e-3 | pending | 0 |  | `/scratch/jy03364/MeZO_/outputs/rtnclip_lowbit_roberta_sst5_seed16_20260519_batch/int8_hsearch/int8_g128_rtnclip_k1_h2e-3_seed16_bs64_ckpt1k` |
| 3e-4 | running | 461 |  | `/scratch/jy03364/MeZO_/outputs/rtnclip_lowbit_roberta_sst5_seed16_20260519_batch/int8_hsearch/int8_g128_rtnclip_k1_h3e-4_seed16_bs64_ckpt1k` |
| 3e-3 | pending | 0 |  | `/scratch/jy03364/MeZO_/outputs/rtnclip_lowbit_roberta_sst5_seed16_20260519_batch/int8_hsearch/int8_g128_rtnclip_k1_h3e-3_seed16_bs64_ckpt1k` |
| 4e-3 | running | 156 |  | `/scratch/jy03364/MeZO_/outputs/rtnclip_lowbit_roberta_sst5_seed16_20260519_batch/int8_hsearch/int8_g128_rtnclip_k1_h4e-3_seed16_bs64_ckpt1k` |
| 5e-3 | pending | 0 |  | `/scratch/jy03364/MeZO_/outputs/rtnclip_lowbit_roberta_sst5_seed16_20260519_batch/int8_hsearch/int8_g128_rtnclip_k1_h5e-3_seed16_bs64_ckpt1k` |
| 1e-2 | running | 18 |  | `/scratch/jy03364/MeZO_/outputs/rtnclip_lowbit_roberta_sst5_seed16_20260519_batch/int8_hsearch/int8_g128_rtnclip_k1_h1e-2_seed16_bs64_ckpt1k` |

## Scheduler

All preferred H100/A100 requests exceeded the 5-minute start window and were replaced by L4 fallback jobs. Active fallback job ids:

- `lane0_fallback_L4_job=45464107`
- `lane1_fallback_L4_job=45464143`
- `lane2_fallback_L4_job=45464174`
- `lane3_fallback_L4_job=45464213`
- `lane4_fallback_L4_job=45464245`
- `lane5_fallback_L4_job=45464256`

## Failed Runs

No smoke/probe failures. INT8 training lanes are running; no completed INT8 failure has been observed yet.

## Resume

Each run directory contains `resume_command.txt`. Examples for currently running/queued INT8 runs are also embedded in `int8_hsearch_summary.csv`.
