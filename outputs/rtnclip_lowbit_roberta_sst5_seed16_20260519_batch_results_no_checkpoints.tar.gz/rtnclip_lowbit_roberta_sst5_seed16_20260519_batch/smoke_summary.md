# RTNClip Low-Bit Smoke Summary

All smoke checks passed: yes
Missing required files: none

| run | status | sec/step | loss | active_frac | alignment | norm_ratio | refreshes |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| int8_wo_g128_rtnclip_sharedgrid_k1_h1e-3_step50 | complete | 0.5672866916656494 | 1.8193359375 | 0.8279405210073294 | 0.9811197285105175 | 1.015025917703038 | 50 |
| int8_wo_g128_rtnclip_sharedgrid_k10_h1e-3_step50 | complete | 0.35750317096710205 | 1.85009765625 | 0.8278780230322841 | 0.9811134506866807 | 1.015015070597779 | 5 |
| int4_wo_g128_rtnclip_sharedgrid_k1_h1e-3_step50 | complete | 0.5385945463180541 | 1.7431640625 | 0.11808657142330012 | 0.4080201886557174 | 2.1833494303209515 | 50 |
| int4_wo_g128_rtnclip_sharedgrid_k10_h1e-3_step50 | complete | 0.34647696018218993 | 1.708984375 | 0.11838351977165712 | 0.40820199525166295 | 2.185695122407074 | 5 |
