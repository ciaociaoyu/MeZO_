# Residual Local H100 Report

Run root: `/scratch/jy03364/MeZO_/runs/residual_local_h100_20260515_172944`

Host: `ra7-1`
Created: `2026-05-15T17:29:53-04:00`
CUDA_VISIBLE_DEVICES: `0`
Git commit: `6964b576b4ef4507e087be3429cb9819ea325bc1`

`nvidia-smi` output and environment capture are saved in `nvidia-smi.txt` and `run_env.txt`.

## Exact Commands Launched

Full command log is also saved in `commands.txt`.

```bash
source "$HOME/miniconda3/etc/profile.d/conda.sh" && conda activate ciao && CUDA_VISIBLE_DEVICES=0 python medium_models/tests/test_residual_grid_update.py
source "$HOME/miniconda3/etc/profile.d/conda.sh" && conda activate ciao && CUDA_VISIBLE_DEVICES=0 python medium_models/tests/test_residual_grid_update.py 2>&1 | tee '/scratch/jy03364/MeZO_/runs/residual_local_h100_20260515_172944/logs/residual_unit_tests.log'
source "/home/jy03364/miniconda3/etc/profile.d/conda.sh" && conda activate ciao && CUDA_VISIBLE_DEVICES=0 python scripts/debug_residual_grid_consistency.py --output-root '/scratch/jy03364/MeZO_/runs/residual_local_h100_20260515_172944/sanity/residual_grid_consistency' --debug-save-dir '/scratch/jy03364/MeZO_/runs/residual_local_h100_20260515_172944/sanity/residual_grid_consistency/debug' --cuda-visible-devices 0 --debug-num-tensors 8 2>&1 | tee '/scratch/jy03364/MeZO_/runs/residual_local_h100_20260515_172944/logs/residual_grid_consistency_debug.log'
source "/home/jy03364/miniconda3/etc/profile.d/conda.sh" && conda activate ciao && cd /scratch/jy03364/MeZO_/medium_models && TASK=SST-5 K=16 SEED=0 DATA_SEED=16 DATASET_MODE=full FULL_DEV_RATIO=0.1 BS=64 LR=0 EPS=3e-3 WD=0 STEP=1 EVAL_STEP=100000 MODEL=roberta-large USE_H=False USE_C=False DATALOADER_SHUFFLE=False EFFICIENT_ZERO_ORDER=True EXTRA_TAG=residual-local-sanity TOKENIZERS_PARALLELISM=false CUDA_VISIBLE_DEVICES=0 bash ./mezo.sh --result_root '/scratch/jy03364/MeZO_/runs/residual_local_h100_20260515_172944/sanity/noop_lr0' --job_name noop_residual_grid_lr0 --dataset_mode full --precision_mode int8 --zo_quantization int8 --zo_update_backend residual_grid --zo_h 3e-3 --zo_two_point_precision fp16 --residual_commit_mode round --residual_dtype fp32 --residual_max_code_step 0 --zo_update_norm_clip 0 --int8_freeze_scale True --log_update_stats_every 1 --save_update_stats_jsonl update_stats.jsonl --zo_probe_every 0 --random_prediction_guard_enabled False --save_strategy no --save_at_last False --no_predict 2>&1 | tee '/scratch/jy03364/MeZO_/runs/residual_local_h100_20260515_172944/logs/sanity_noop_lr0.log'
source "/home/jy03364/miniconda3/etc/profile.d/conda.sh" && conda activate ciao && cd /scratch/jy03364/MeZO_/medium_models && TASK=SST-5 K=16 SEED=0 DATA_SEED=16 DATASET_MODE=full FULL_DEV_RATIO=0.1 BS=64 LR=5e-5 EPS=3e-3 WD=0 STEP=500 EVAL_STEP=100 MODEL=roberta-large USE_H=False USE_C=False DATALOADER_SHUFFLE=False EFFICIENT_ZERO_ORDER=True EXTRA_TAG=residual-local-h100 TOKENIZERS_PARALLELISM=false CUDA_VISIBLE_DEVICES=0 bash ./mezo.sh --result_root '/scratch/jy03364/MeZO_/runs/residual_local_h100_20260515_172944' --job_name 'residual_grid_round_step1_lr5e-5_clip5_step500' --dataset_mode full --precision_mode int8 --zo_quantization int8 --zo_update_backend residual_grid --direction_type dense --sparse_rate 1.0 --sparse_mode none --sparse_rescale none --zo_h 3e-3 --zo_two_point_precision fp16 --residual_commit_mode round --residual_dtype fp32 --residual_max_code_step 1 --zo_update_norm_clip 5 --int8_freeze_scale True --log_update_stats_every 1 --save_update_stats_jsonl update_stats.jsonl --zo_probe_every 0 --random_prediction_guard_enabled False --save_strategy no --save_at_last False --no_predict 2>&1 | tee '/scratch/jy03364/MeZO_/runs/residual_local_h100_20260515_172944/logs/residual_grid_round_step1_lr5e-5_clip5_step500.log'
source "/home/jy03364/miniconda3/etc/profile.d/conda.sh" && conda activate ciao && cd /scratch/jy03364/MeZO_/medium_models && TASK=SST-5 K=16 SEED=0 DATA_SEED=16 DATASET_MODE=full FULL_DEV_RATIO=0.1 BS=64 LR=1e-4 EPS=3e-3 WD=0 STEP=500 EVAL_STEP=100 MODEL=roberta-large USE_H=False USE_C=False DATALOADER_SHUFFLE=False EFFICIENT_ZERO_ORDER=True EXTRA_TAG=residual-local-h100 TOKENIZERS_PARALLELISM=false CUDA_VISIBLE_DEVICES=0 bash ./mezo.sh --result_root '/scratch/jy03364/MeZO_/runs/residual_local_h100_20260515_172944' --job_name 'residual_grid_round_step1_lr1e-4_clip2_step500' --dataset_mode full --precision_mode int8 --zo_quantization int8 --zo_update_backend residual_grid --direction_type dense --sparse_rate 1.0 --sparse_mode none --sparse_rescale none --zo_h 3e-3 --zo_two_point_precision fp16 --residual_commit_mode round --residual_dtype fp32 --residual_max_code_step 1 --zo_update_norm_clip 2 --int8_freeze_scale True --log_update_stats_every 1 --save_update_stats_jsonl update_stats.jsonl --zo_probe_every 0 --random_prediction_guard_enabled False --save_strategy no --save_at_last False --no_predict 2>&1 | tee '/scratch/jy03364/MeZO_/runs/residual_local_h100_20260515_172944/logs/residual_grid_round_step1_lr1e-4_clip2_step500.log'
source "/home/jy03364/miniconda3/etc/profile.d/conda.sh" && conda activate ciao && cd /scratch/jy03364/MeZO_/medium_models && TASK=SST-5 K=16 SEED=0 DATA_SEED=16 DATASET_MODE=full FULL_DEV_RATIO=0.1 BS=64 LR=7e-5 EPS=3e-3 WD=0 STEP=500 EVAL_STEP=100 MODEL=roberta-large USE_H=False USE_C=False DATALOADER_SHUFFLE=False EFFICIENT_ZERO_ORDER=True EXTRA_TAG=residual-local-h100 TOKENIZERS_PARALLELISM=false CUDA_VISIBLE_DEVICES=0 bash ./mezo.sh --result_root '/scratch/jy03364/MeZO_/runs/residual_local_h100_20260515_172944' --job_name 'residual_grid_round_step1_lr7e-5_clip3_step500' --dataset_mode full --precision_mode int8 --zo_quantization int8 --zo_update_backend residual_grid --direction_type dense --sparse_rate 1.0 --sparse_mode none --sparse_rescale none --zo_h 3e-3 --zo_two_point_precision fp16 --residual_commit_mode round --residual_dtype fp32 --residual_max_code_step 1 --zo_update_norm_clip 3 --int8_freeze_scale True --log_update_stats_every 1 --save_update_stats_jsonl update_stats.jsonl --zo_probe_every 0 --random_prediction_guard_enabled False --save_strategy no --save_at_last False --no_predict 2>&1 | tee '/scratch/jy03364/MeZO_/runs/residual_local_h100_20260515_172944/logs/residual_grid_round_step1_lr7e-5_clip3_step500.log'
source "/home/jy03364/miniconda3/etc/profile.d/conda.sh" && conda activate ciao && cd /scratch/jy03364/MeZO_/medium_models && TASK=SST-5 K=16 SEED=0 DATA_SEED=16 DATASET_MODE=full FULL_DEV_RATIO=0.1 BS=64 LR=7e-5 EPS=3e-3 WD=0 STEP=2000 EVAL_STEP=100 MODEL=roberta-large USE_H=False USE_C=False DATALOADER_SHUFFLE=False EFFICIENT_ZERO_ORDER=True EXTRA_TAG=residual-local-h100 TOKENIZERS_PARALLELISM=false CUDA_VISIBLE_DEVICES=0 bash ./mezo.sh --result_root '/scratch/jy03364/MeZO_/runs/residual_local_h100_20260515_172944' --job_name 'residual_grid_round_step1_lr7e-5_clip3_step500_promote_step2000' --dataset_mode full --precision_mode int8 --zo_quantization int8 --zo_update_backend residual_grid --direction_type dense --sparse_rate 1.0 --sparse_mode none --sparse_rescale none --zo_h 3e-3 --zo_two_point_precision fp16 --residual_commit_mode round --residual_dtype fp32 --residual_max_code_step 1 --zo_update_norm_clip 3 --int8_freeze_scale True --log_update_stats_every 1 --save_update_stats_jsonl update_stats.jsonl --zo_probe_every 0 --random_prediction_guard_enabled False --save_strategy no --save_at_last False --no_predict 2>&1 | tee '/scratch/jy03364/MeZO_/runs/residual_local_h100_20260515_172944/logs/residual_grid_round_step1_lr7e-5_clip3_step500_promote_step2000.log'
```

The optional `lr=1e-4, clip=5` 500-step repeat was skipped to prioritize the required 2k promotion on the interactive H100.

## Sanity Checks

Passed.

| check | result |
|---|---:|
| residual unit tests | 7 tests OK |
| debug consistency synthetic round/floor/stochastic | passed |
| debug freeze scale | true |
| debug global grid error after snap | 0.0 |
| no-op active_frac max | 0.0 |
| no-op actual_update_norm max | 0.0 |
| no-op grid_error_norm max | 0.0 |
| no-op residual_bound_violation_frac max | 0.0 |
| no-op scale_drift_max | 0.0 |

## 500-Step Results

Eval step numbers below follow the existing metrics CSV indexing; each 500-step run completed through `global_step=500`.

| run | lr | clip | best acc | best loss | last acc | last loss | active last | cos last | ratio last | p99 last | grid last | violation last | scale drift |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| `residual_grid_round_step1_lr5e-5_clip5_step500` | 5e-5 | 5 | 0.3677 | 1.5307 | 0.3677 | 1.5307 | 0.01948 | 0.1402 | 7.1320 | 0.4950 | 0.0 | 0.0 | 0.0 |
| `residual_grid_round_step1_lr1e-4_clip2_step500` | 1e-4 | 2 | 0.3126 | 1.5486 | 0.3126 | 1.5486 | 0.02621 | 0.1637 | 5.4629 | 0.4941 | 0.0 | 0.0 | 0.0 |
| `residual_grid_round_step1_lr7e-5_clip3_step500` | 7e-5 | 3 | 0.3712 | 1.5153 | 0.3712 | 1.5153 | 0.04078 | 0.2031 | 4.8364 | 0.4949 | 0.0 | 0.0 | 0.0 |

All required 500-step runs had no NaN, no grid error, no residual-bound violation, and zero scale drift under `int8_freeze_scale=True`.

## Promotion Choice

Chosen: `residual_grid_round_step1_lr7e-5_clip3_step500`.

Why:

- Best 500-step validation accuracy: 0.3712.
- Best 500-step validation loss: 1.5153.
- Best final cosine among the required 500-step runs: 0.2031.
- Lowest final norm ratio among the two competitive 500-step runs: 4.8364 vs 7.1320 for `lr=5e-5, clip=5`.
- No NaN, no scale drift, no grid error, no residual-bound violation.

## 2k Promotion Result

Promoted run: `residual_grid_round_step1_lr7e-5_clip3_step500_promote_step2000`.

| metric | value |
|---|---:|
| completed global step | 2000 |
| best eval acc | 0.4625292740 |
| best eval acc step | 1990 |
| last eval acc | 0.4625292740 |
| last eval step | 1990 |
| best eval loss | 1.3812105656 |
| best eval loss step | 1990 |
| last eval loss | 1.3812105656 |
| final train loss | 1.4608078003 |
| final active_frac | 0.0410366089 |
| final cos_intended_actual | 0.2035991968 |
| final actual_over_intended_norm_ratio | 4.9122855232 |
| final saturation_frac | 0.0000275802 |
| final residual_over_scale_p99 | 0.4949936768 |
| final residual_bound_violation_frac | 0.0 |
| final grid_error_norm | 0.0 |
| scale_drift_max | 0.0 |

The 2k run remained stable and was still improving at the final checkpoint. The final eval accuracy was the run best, and the final eval loss was also the run best.

## Backend Interpretation

Residual-grid should no longer be treated as only a short-run mechanical diagnostic. This result supports keeping it as a secondary backend candidate: it maintained clean grid mechanics through 2k steps and improved validation performance beyond the 500-step horizon.

It should not displace the main paper contribution. The main contribution remains perturbation visibility and h-window construction. Residual-grid still needs a longer stability run before being described as a reliable training backend.

## Recommended Next Residual Action

Run one 5k candidate later with the same setting:

- `lr=7e-5`
- `update_norm_clip=3`
- `h=3e-3`
- `commit_mode=round`
- `max_code_step=1`
- `residual_dtype=fp32`
- `int8_freeze_scale=True`
- `seed=0`

Do not start it automatically from this report. Keep it isolated from the main dense/window/sparse cluster jobs. Sparse + residual can be tested later only after the 5k dense residual candidate confirms stability.

## Artifacts

- `summary_residual.csv`
- `summary_residual.md`
- `commands.txt`
- `sanity_summary.json`
- `logs/`

Plots were requested if matplotlib was available. Matplotlib is not installed in this environment, so no plot files were generated.
