# SafeOverride 6h A100 Summary

Created: `2026-06-18T03:39:47`
Git commit: `da646cf183101530c17d295ef96c553f6ab2fd7d`
GPU: `0, NVIDIA A100-SXM4-80GB, 4 MiB, 81920 MiB, 0 %`

## Policy

SafeOverride keeps `h=1e-3` when the default is already safe or validated by existing runs. It overrides only for default-failure candidates such as INT4 prefix where the existing seed-fixed full runs show clear improvement.

## Result Table

| model | task | precision | perturbation_mode | default_h | selected_h | selected_policy | default_acc | selected_acc | delta_vs_default | win_tie_loss | run_type | seed | default_in_window | selected_reason | source_path |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| roberta-large | trec | int4 | prefix_int4 | 0.001 | 0.0949896412434653 | hstar_cleanGL | 0.2417582417582417 | 0.7234432234432234 | 0.48168498168498175 | win | existing_full | 16 | False | prefix default-failure candidate; selected from seed-fixed full hstar result | outputs/int4_sparse_prefix_seedfixed_int4fd_20k_20260523_171841/int4_hsearch_summary.csv |
| roberta-large | sst-2 | int4 | prefix_int4 | 0.001 | 0.0886419832658425 | hstar_cleanGL | 0.6120267260579064 | 0.8911655530809206 | 0.2791388270230142 | win | existing_full | 16 | False | prefix default-failure candidate; selected from seed-fixed full hstar result | outputs/int4_sparse_prefix_seedfixed_int4fd_20k_20260523_171841/int4_hsearch_summary.csv |
| roberta-large | sst-5 | int4 | prefix_int4 | 0.001 | 0.0804720147886286 | hstar_cleanGL | 0.319672131147541 | 0.4250585480093676 | 0.10538641686182659 | win | existing_full | 16 | False | prefix default-failure candidate; selected from seed-fixed full hstar result | outputs/int4_sparse_prefix_seedfixed_int4fd_20k_20260523_171841/int4_hsearch_summary.csv |
| roberta-large | rte | int4 | prefix_int4 | 0.001 | 0.072807568266058 | hstar_cleanGL | 0.5341365461847389 | 0.5622489959839357 | 0.028112449799196804 | win | existing_full | 16 | False | prefix default-failure candidate; selected from seed-fixed full hstar result | outputs/int4_sparse_prefix_seedfixed_int4fd_20k_20260523_171841/int4_hsearch_summary.csv |
| roberta-large | sst-5 | int4 | sparse_p0p1 | 0.001 | 0.001 | safe_override_default | 0.4812646370023419 | 0.4812646370023419 | 0.0 | tie | existing_full | 16 | True | existing seed-fixed sparse full run validates default; keep tie | outputs/int4_sparse_prefix_seedfixed_int4fd_20k_20260523_171841/int4_hsearch_summary.csv |
| roberta-large | sst-5 | int8 | sparse_p0p1 | 0.001 | 0.001 | safe_override_default | 0.2704918032786885 | 0.2704918032786885 | 0.0 | tie | pilot_2k | 16 | True | default in window / policy fallback: no_training_validation_use_probe_only_candidate | safe_override_6h_a100_bundle/pilot_runs/roberta_sst5_int8_sparse_p0p1/int8_hsearch_summary.csv |
| facebook/opt-1.3b | sst-5 | int8 | sparse_p0p1 | 0.001 | 0.001 | safe_override_default |  |  |  | unknown | not_run | 16 | True | default in window / policy fallback: no_training_validation_use_probe_only_candidate |  |
| facebook/opt-1.3b | sst-5 | int8 | dense | 0.001 | 0.001 | safe_override_default | 0.375 | 0.375 | 0.0 | tie | existing_full_or_medium | 16 | True | default in window / policy fallback: existing_training_validates_or_ties_probe_selected | /scratch/jy03364/MeZO_/outputs/quantizer_robustness_int8_window/h_acc_results.csv |
| facebook/opt-1.3b | trec | int8 | dense | 0.001 | 0.001 | safe_override_default | 0.32421875 | 0.32421875 | 0.0 | tie | pilot_2k | 16 | True | no interval policy; conservative fallback to default | safe_override_6h_a100_bundle/pilot_runs/opt13b_trec_int8_dense_pilot/summary_trec.csv |
| facebook/opt-1.3b | rte | int8 | dense | 0.001 | 0.001 | safe_override_default | 0.53515625 | 0.53515625 | 0.0 | tie | pilot_2k | 16 | True | no interval policy; conservative fallback to default | safe_override_6h_a100_bundle/pilot_runs/opt13b_rte_int8_dense_pilot/summary_rte.csv |

## Run List Actions

| priority | model | task | precision | perturbation_mode | selected_h | selected_policy | action |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | roberta-large | trec | int4 | prefix_int4 | 0.0949896412434653 | hstar_cleanGL | skip_existing_full_comparison |
| 2 | roberta-large | sst-2 | int4 | prefix_int4 | 0.0886419832658425 | hstar_cleanGL | skip_existing_full_comparison |
| 3 | roberta-large | sst-5 | int4 | prefix_int4 | 0.0804720147886286 | hstar_cleanGL | skip_existing_full_comparison |
| 4 | roberta-large | rte | int4 | prefix_int4 | 0.072807568266058 | hstar_cleanGL | skip_existing_full_comparison |
| 5 | roberta-large | sst-5 | int4 | sparse_p0p1 | 0.001 | safe_override_default | skip_existing_full_comparison |
| 6 | roberta-large | sst-5 | int8 | sparse_p0p1 | 0.001 | safe_override_default | skip_existing_partial_reference |
| 7 | facebook/opt-1.3b | sst-5 | int8 | sparse_p0p1 | 0.001 | safe_override_default | not_launched_no_sparse_opt_runner |
| 8 | facebook/opt-1.3b | sst-5 | int8 | dense | 0.001 | safe_override_default | skip_existing_partial_reference |
| 9 | facebook/opt-1.3b | trec | int8 | dense | 0.001 | safe_override_default | skip_existing_partial_reference |
| 10 | facebook/opt-1.3b | rte | int8 | dense | 0.001 | safe_override_default | skip_existing_partial_reference |

## Answers

1. SafeOverride retains default `h=1e-3` for configs where selected h equals default or where existing full sparse results show default remains strongest.
2. SafeOverride overrides default for RoBERTa prefix INT4 TREC/SST-2/SST-5/RTE using `hstar_cleanGL` from seed-fixed full runs.
3. The prefix overrides exceed default on all four P1 tasks in the existing 20k seed-fixed results.
4. Missing/failed items are marked in `runs_to_launch.csv`; OPT sparse lacks a compatible sparse runner in this bundle.
5. The RoBERTa prefix INT4 full 20k comparisons are directly paper-usable. Existing sparse/default tie rows are useful as SafeOverride fallback evidence.
6. Any `existing_pilot`, `not_run`, or `not_launched_*` rows should not be treated as full results.
