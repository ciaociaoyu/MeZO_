# INT8 RTNClip H-Search Summary

For low-bit settings, the canonical nMSE in this runner is `lowbit_true_nmse`, an alias of the dequantized effective-displacement nMSE `delta_visibility_nmse`: MSE of `Q_t(w_t+h u)-Q_t(w_t-h u)` against `2h u` after dequantization to floating point. Legacy `nMSE_fd_true`, if present, is reported only for reference and is not used for selecting h.

| h | status | steps | best_acc | last_acc | best_loss | last_loss | run_dir |
| --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| 1e-3 | complete | 2000 | 0.27049180327868855 | 0.25995316159250587 | 1.583828856850117 | 1.584807706381733 | `safe_override_6h_a100_bundle/pilot_runs/roberta_sst5_int8_sparse_p0p1/int8_hsearch/safe_override_roberta_sst5_int8_sparse_p0p1_default_h1e-3_pilot2k` |
