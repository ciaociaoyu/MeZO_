# MeZO RoBERTa INT8 h-policy extension

Clean distribution repo for RoBERTa-large MeZO INT8 full-dataset experiments.

This repo intentionally contains code and launch scripts only. It does not track
datasets, checkpoints, caches, historical results, or machine-specific absolute
paths.

## Experiment scope

- Model: `roberta-large`
- Training path: `medium_models/run.py` through `medium_models/mezo.sh`
- Precision: INT8, current local QuZO semantics (`quant_bits=8`, `zo_quantization=int8`)
- Quantization: `groupwise_symmetric`, group size 128
- Update backend: `fp16_master`
- Datasets: `SST-2`, `RTE`, `MNLI`, `trec`
- Data setting: full dataset, materialized as `full-16` splits through the existing MeZO data resolver
- Seed and data seed: 16
- Steps: 20000
- Batch size: 64
- Learning rate: `1e-6`
- h policies:
  - `mezo_default`: fixed `h=1e-3`
  - `ours`: `simple2pt_corrected`
  - `fd_baseline`: FP16 proxy finite-difference baseline `eps^(1/3)`
  - `small_fixed`: fixed `h=1e-5`

The launcher records `fd_true_nmse`, `h_policy`, `h_value`, and h computation
metadata into each run's `run_summary.json`, `run_metadata.json`, and
`metrics/probe_h_policy.jsonl`.

## Clone and install

```bash
git clone <repo-url> mezo-int8-roberta-extension
cd mezo-int8-roberta-extension

# Creates/activates a conda env, installs dependencies, downloads LM-BFF data,
# and materializes full-dataset seed=16 splits for the target tasks.
bash scripts/setup_env.sh
```

Useful setup overrides:

```bash
ENV_NAME=ciao SKIP_CONDA=1 SKIP_TORCH=1 bash scripts/setup_env.sh
SKIP_DATA=1 bash scripts/setup_env.sh
```

## Smoke test

Run a short INT8 RoBERTa smoke test using `h_policy=ours`:

```bash
bash scripts/smoke.sh
```

The smoke test runs 10 steps by default and verifies:

- `run_summary.json` exists
- `run_metadata.json` exists
- `metrics/probe_h_policy.jsonl` exists
- required fields are present: `fd_true_nmse`, `h_policy`, `h_value`, `simple2pt_corrected`

Shorter/faster smoke:

```bash
SMOKE_STEPS=5 SMOKE_BATCH_SIZE=2 HSTAR_NUM_G_DIRS=1 HSTAR_NUM_L_DIRS=1 bash scripts/smoke.sh
```

## Run one job locally

```bash
python scripts/run_int8_roberta.py \
  --task SST-2 \
  --h_policy mezo_default \
  --steps 20000 \
  --eval_steps 1000 \
  --batch_size 64 \
  --result_root outputs/int8_roberta_full
```

Run the `simple2pt_corrected` h-star policy:

```bash
python scripts/run_int8_roberta.py \
  --task RTE \
  --h_policy ours \
  --steps 20000 \
  --eval_steps 1000 \
  --batch_size 64 \
  --result_root outputs/int8_roberta_full
```

## Submit all dataset x h-policy jobs on Slurm

The submitter creates `configs/int8_roberta_extension_manifest.csv` with
4 datasets x 4 h policies = 16 full-dataset jobs and submits one Slurm array.

Resource parameters are environment variables, not hardcoded paths:

```bash
ACCOUNT=<your-account> \
PARTITION=L4GPU \
GPUS=1 \
GRES=gpu:1 \
TIME=24:00:00 \
CPUS_PER_TASK=8 \
MEM=64G \
MAX_CONCURRENT=7 \
CONDA_ENV=mezo-int8 \
CONFIRM_SUBMIT=1 \
bash scripts/submit_all_int8_roberta.sh
```

By default the submitter targets `PARTITION=L4GPU` and clamps
`MAX_CONCURRENT` to at most 7, so at most seven one-GPU tasks run at once.

Dry run without submitting:

```bash
bash scripts/submit_all_int8_roberta.sh
```

All launch scripts infer the project root from the script location by default,
so they can also be called from another working directory:

```bash
/path/to/mezo-int8-roberta-extension/scripts/submit_all_int8_roberta.sh
```

For Slurm jobs, `PROJECT_ROOT` is exported from the submitter after this
auto-detection. If a site submits the batch script directly, set `PROJECT_ROOT`
to the copied repo root.

## Results

Each run writes under:

```text
outputs/int8_roberta_full/<run_name>/seed16/
```

Important files:

```text
run_summary.json
run_metadata.json
h_policy_metadata.json
probe_stats.jsonl
metrics/probe_h_policy.jsonl
metrics_logs/zo_directional_probe.csv
```

Summarize completed runs:

```bash
python scripts/summarize_results.py \
  --root outputs/int8_roberta_full \
  --output outputs/int8_roberta_full/summary.csv
```

## h-star policy

`ours` is `simple2pt_corrected`:

```text
Delta = coordinate-weighted RMS(INT8 group scale) / sqrt(6)
G     = median_h sqrt(pi/2) * mean_u |d2_clean32(h; u)|, h in {1e-4, 3e-4, 1e-3}
L     = q90_u |K_clean32(1e-3; u)| / ||u||^2
h     = (Delta^2 * G^2 / (16 * L^2 * d * (d + 2)))^(1/4)
```

The policy is computed before training and saved in `h_policy_metadata.json`.

## Notes

- Paths are derived from the repo root at runtime.
- Data and output directories are ignored by git.
- This distribution does not include old checkpoints, result packages, logs, or cache files.
- Do not use this repo for INT4, sparse, residual-grid, LoRA, OPT, or non-target tasks unless you intentionally extend it.
