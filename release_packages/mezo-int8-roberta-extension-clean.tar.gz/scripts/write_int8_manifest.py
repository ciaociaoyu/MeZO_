#!/usr/bin/env python3
"""Write dataset x h-policy manifest for the INT8 extension jobs."""

from __future__ import annotations

import argparse
import csv
from pathlib import Path


DATASETS = ["SST-2", "RTE", "MNLI", "trec"]
H_POLICIES = ["mezo_default", "ours", "fd_baseline", "small_fixed"]


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", default="configs/int8_roberta_extension_manifest.csv")
    parser.add_argument("--steps", type=int, default=20000)
    parser.add_argument("--eval_steps", type=int, default=1000)
    parser.add_argument("--batch_size", type=int, default=64)
    parser.add_argument("--learning_rate", default="1e-6")
    parser.add_argument("--dataset_mode", choices=["full", "fewshot"], default="full")
    parser.add_argument("--seed", type=int, default=16)
    parser.add_argument("--data_seed", type=int, default=16)
    parser.add_argument("--k", type=int, default=16)
    args = parser.parse_args()
    path = Path(args.output)
    path.parent.mkdir(parents=True, exist_ok=True)
    rows = []
    for task in DATASETS:
        for policy in H_POLICIES:
            mode_tag = "full" if args.dataset_mode == "full" else f"k{args.k}"
            run_name = f"roberta_large_int8_{task}_{mode_tag}_seed{args.seed}_{policy}_step{args.steps}".replace("/", "_")
            rows.append({
                "task": task,
                "h_policy": policy,
                "model": "roberta-large",
                "dataset_mode": args.dataset_mode,
                "k": args.k,
                "seed": args.seed,
                "data_seed": args.data_seed,
                "steps": args.steps,
                "eval_steps": args.eval_steps,
                "batch_size": args.batch_size,
                "learning_rate": args.learning_rate,
                "run_name": run_name,
            })
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)
    print(path)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
