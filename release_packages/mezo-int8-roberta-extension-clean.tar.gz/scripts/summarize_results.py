#!/usr/bin/env python3
"""Collect run_summary.json files into a compact CSV."""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path


FIELDS = [
    "run_name", "task", "h_policy", "h_value", "fd_true_nmse",
    "best_eval_acc", "last_eval_acc", "best_eval_loss", "last_eval_loss",
    "training_exit_code", "precision_mode", "quant_bits", "quantization_algorithm",
]


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", default="outputs/int8_roberta_extension")
    parser.add_argument("--output", default="outputs/int8_roberta_extension/summary.csv")
    args = parser.parse_args()
    root = Path(args.root)
    rows = []
    for path in root.glob("*/seed*/run_summary.json"):
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            continue
        row = {field: data.get(field) for field in FIELDS}
        row["run_dir"] = str(path.parent)
        row["run_name"] = row.get("run_name") or path.parent.parent.name
        rows.append(row)
    out = Path(args.output)
    out.parent.mkdir(parents=True, exist_ok=True)
    with out.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["run_dir"] + FIELDS)
        writer.writeheader()
        writer.writerows(rows)
    print(out)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
