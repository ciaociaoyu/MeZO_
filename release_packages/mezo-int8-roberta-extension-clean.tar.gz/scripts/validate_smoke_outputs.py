#!/usr/bin/env python3
"""Validate that a smoke run produced the required metadata/log fields."""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
from typing import Any, Dict


REQUIRED_FIELDS = {"fd_true_nmse", "h_policy", "h_value", "simple2pt_corrected"}


def load_json(path: Path) -> Dict[str, Any]:
    if not path.exists():
        raise FileNotFoundError(path)
    return json.loads(path.read_text(encoding="utf-8"))


def assert_fields(name: str, data: Dict[str, Any], required) -> None:
    missing = [k for k in required if k not in data]
    if missing:
        raise AssertionError(f"{name} missing fields: {missing}")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run_dir", required=True)
    args = parser.parse_args()
    run_dir = Path(args.run_dir)
    summary = load_json(run_dir / "run_summary.json")
    metadata = load_json(run_dir / "run_metadata.json")
    h_meta = load_json(run_dir / "h_policy_metadata.json")
    assert_fields("run_summary.json", summary, REQUIRED_FIELDS)
    assert_fields("run_metadata.json", metadata, REQUIRED_FIELDS)
    assert_fields("h_policy_metadata.json", h_meta, {"h_policy", "h_value", "simple2pt_corrected"})

    probe_jsonl = run_dir / "metrics" / "probe_h_policy.jsonl"
    if not probe_jsonl.exists():
        raise FileNotFoundError(probe_jsonl)
    rows = [json.loads(line) for line in probe_jsonl.read_text(encoding="utf-8").splitlines() if line.strip()]
    if not rows:
        raise AssertionError(f"{probe_jsonl} is empty")
    assert_fields("metrics/probe_h_policy.jsonl", rows[-1], REQUIRED_FIELDS)

    if rows[-1].get("fd_true_nmse") is None:
        raise AssertionError("fd_true_nmse is None in metrics/probe_h_policy.jsonl")
    if rows[-1].get("h_policy") != "ours":
        raise AssertionError(f"smoke should exercise h_policy=ours, saw {rows[-1].get('h_policy')}")
    if not rows[-1].get("simple2pt_corrected"):
        raise AssertionError("simple2pt_corrected flag is false")

    print(json.dumps({
        "status": "ok",
        "run_dir": str(run_dir),
        "h_policy": rows[-1].get("h_policy"),
        "h_value": rows[-1].get("h_value"),
        "fd_true_nmse": rows[-1].get("fd_true_nmse"),
    }, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
