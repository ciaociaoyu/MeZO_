#!/usr/bin/env python3
"""Resolve the training h value and record h-policy metadata.

The distributed experiment uses exactly four policies:
  - mezo_default: fixed h=1e-3
  - small_fixed: fixed h=1e-5
  - fd_baseline: classical fp16 eps^(1/3) finite-difference baseline
  - ours: simple2pt_corrected

simple2pt_corrected uses the current simplified estimator:
  Delta = coordinate-weighted RMS(INT8 group scale) / sqrt(6)
  G     = median_h sqrt(pi/2) * mean_u |d2_clean32(h; u)|, h in {1e-4,3e-4,1e-3}
  L     = q90_u |K_clean32(h2;u)| / ||u||^2, h2=1e-3
  h     = (Delta^2 G^2 / (16 L^2 d(d+2)))^(1/4)

The fallback path is explicit in metadata and is intended only to keep smoke
tests and misconfigured environments debuggable.
"""

from __future__ import annotations

import argparse
import json
import math
import os
import random
import sys
from dataclasses import asdict
from pathlib import Path
from types import SimpleNamespace
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np


H_POLICIES = {"mezo_default", "ours", "fd_baseline", "small_fixed"}
H_GRID_G = [1e-4, 3e-4, 1e-3]
H_L_DEFAULT = 1e-3


def repo_root() -> Path:
    return Path(__file__).resolve().parents[1]


def repo_path(path_value: str) -> Path:
    path = Path(path_value).expanduser()
    if path.is_absolute():
        return path
    return repo_root() / path


def _safe_float(value: Any, default: Optional[float] = None) -> Optional[float]:
    try:
        out = float(value)
    except Exception:
        return default
    if not math.isfinite(out):
        return default
    return out


def canonical_task(task: str) -> str:
    key = str(task).strip()
    mapping = {
        "sst2": "sst-2",
        "SST-2": "sst-2",
        "sst-2": "sst-2",
        "RTE": "rte",
        "rte": "rte",
        "MNLI": "mnli",
        "mnli": "mnli",
        "TREC": "trec",
        "trec": "trec",
    }
    return mapping.get(key, key.lower())


def task_for_data_dir(task: str) -> str:
    mapping = {
        "sst-2": "SST-2",
        "sst2": "SST-2",
        "rte": "RTE",
        "mnli": "MNLI",
        "trec": "trec",
    }
    return mapping.get(canonical_task(task), task)


def task_template_mapping(task: str) -> Tuple[str, str, Dict[str, Any]]:
    task = canonical_task(task)
    if task == "sst-2":
        return "*cls**sent_0*_It_was*mask*.*sep+*", "{'0':'terrible','1':'great'}", {}
    if task == "rte":
        return "*cls**sent-_0*?*mask*,*+sentl_1**sep+*", "{'not_entailment':'No','entailment':'Yes'}", {
            "max_seq_length": 256,
            "first_sent_limit": 240,
        }
    if task == "mnli":
        return "*cls**sent-_0*?*mask*,*+sentl_1**sep+*", "{'contradiction':'No','entailment':'Yes','neutral':'Maybe'}", {
            "max_seq_length": 256,
            "first_sent_limit": 240,
        }
    if task == "trec":
        return "*cls**mask*:*+sent_0**sep+*", "{0:'Description',1:'Entity',2:'Expression',3:'Human',4:'Location',5:'Number'}", {
            "first_sent_limit": 110,
        }
    raise ValueError(f"Unsupported task for this release: {task}")


def find_data_dir(data_root: Path, task: str, k: int, seed: int, dataset_mode: str = "full") -> Path:
    names = [task_for_data_dir(task), canonical_task(task), str(task)]
    if str(dataset_mode).lower() == "full":
        suffixes = [f"full-{seed}", f"{k}-{seed}"]
    else:
        suffixes = [f"{k}-{seed}", f"full-{seed}"]
    for name in names:
        for suffix in suffixes:
            path = data_root / name / suffix
            if path.is_dir():
                return path
    suffix = f"full-{seed}" if str(dataset_mode).lower() == "full" else f"{k}-{seed}"
    return data_root / task_for_data_dir(task) / suffix


def fixed_policy_metadata(policy: str) -> Dict[str, Any]:
    if policy == "mezo_default":
        h = 1e-3
        method = "fixed_mezo_default"
    elif policy == "small_fixed":
        h = 1e-5
        method = "fixed_small"
    elif policy == "fd_baseline":
        h = float(np.finfo(np.float16).eps ** (1.0 / 3.0))
        method = "fd_eps13_raw_fp16_proxy"
    else:
        raise ValueError(policy)
    return {
        "h_policy": policy,
        "h_value": h,
        "method": method,
        "simple2pt_corrected": {
            "enabled": False,
            "method": "simple2pt_corrected",
        },
        "warnings": [],
    }


def _load_torch_stack() -> Tuple[Any, Any, Any, Any, Any, Any, Any]:
    root = repo_root()
    medium = root / "medium_models"
    if str(root) not in sys.path:
        sys.path.insert(0, str(root))
    if str(medium) not in sys.path:
        sys.path.insert(0, str(medium))

    import torch
    from torch.utils.data import DataLoader
    from transformers import AutoConfig, AutoTokenizer

    from run import DynamicDataTrainingArguments, MODEL_TYPES, MyDataCollatorWithPadding
    from src.dataset import FewShotDataset
    from src.processors import num_labels_mapping

    return torch, AutoConfig, AutoTokenizer, DynamicDataTrainingArguments, MODEL_TYPES, MyDataCollatorWithPadding, (FewShotDataset, DataLoader, num_labels_mapping)


def _make_batch(
    *,
    model_name: str,
    task: str,
    data_root: Path,
    k: int,
    seed: int,
    dataset_mode: str,
    batch_size: int,
    device: Any,
) -> Tuple[Any, Any, List[Any], int]:
    torch, AutoConfig, AutoTokenizer, DynamicDataTrainingArguments, MODEL_TYPES, MyDataCollatorWithPadding, rest = _load_torch_stack()
    FewShotDataset, DataLoader, num_labels_mapping = rest

    task_name = canonical_task(task)
    template, mapping, extra = task_template_mapping(task_name)
    data_dir = find_data_dir(data_root, task_name, k, seed, dataset_mode=dataset_mode)
    if not data_dir.is_dir():
        raise FileNotFoundError(
            f"Few-shot data not found: {data_dir}. Run scripts/setup_env.sh or generate K={k}, seed={seed} first."
        )

    data_args = DynamicDataTrainingArguments(
        task_name=task_name,
        data_dir=str(data_dir),
        data_root=str(data_root),
        dataset_mode=str(dataset_mode).lower(),
        num_k=int(k),
        template=template,
        mapping=mapping,
    )
    data_args.prompt = True
    data_args.overwrite_cache = False
    for key, value in extra.items():
        setattr(data_args, key, value)

    num_labels = num_labels_mapping[task_name]
    config = AutoConfig.from_pretrained(model_name, num_labels=num_labels, finetuning_task=task_name)
    tokenizer = AutoTokenizer.from_pretrained(model_name, additional_special_tokens=[])
    tokenizer.model_type = config.model_type
    model_cls = MODEL_TYPES[config.model_type]
    model = model_cls.from_pretrained(model_name, config=config)
    model.model_args = SimpleNamespace(
        few_shot_type="prompt",
        use_task_word=False,
        l2_loss=False,
        sfc=False,
        icl_sfc=False,
    )
    model.data_args = data_args
    model.tokenizer = tokenizer

    train_dataset = FewShotDataset(data_args, tokenizer=tokenizer, mode="train", use_demo=False)
    eval_dataset = FewShotDataset(data_args, tokenizer=tokenizer, mode="dev", use_demo=False)
    label_word_source = eval_dataset if eval_dataset is not None else train_dataset
    if getattr(label_word_source, "label_word_list", None) is not None:
        model.label_word_list = torch.tensor(label_word_source.label_word_list).long()

    collator = MyDataCollatorWithPadding(tokenizer)
    loader = DataLoader(train_dataset, batch_size=int(batch_size), shuffle=False, collate_fn=collator)
    batch = next(iter(loader))
    batch = {k: (v.to(device) if hasattr(v, "to") else v) for k, v in batch.items()}

    model.to(device)
    if getattr(model, "label_word_list", None) is not None:
        model.label_word_list = model.label_word_list.to(device)
    model.eval()
    return model, batch, [(n, p) for n, p in model.named_parameters() if p.requires_grad and p.is_floating_point()], int(num_labels)


def _loss(model: Any, batch: Dict[str, Any]) -> float:
    import torch

    with torch.no_grad():
        out = model(**batch)
        val = out[0] if isinstance(out, (tuple, list)) else out.loss
        return float(val.detach().float().item())


def _add_direction(torch: Any, params: Sequence[Tuple[str, Any]], seed: int, scale: float) -> float:
    torch.manual_seed(int(seed))
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(int(seed))
    norm_sq = 0.0
    with torch.no_grad():
        for _, p in params:
            z = torch.randn_like(p.data, dtype=p.data.dtype)
            norm_sq += float(torch.sum(z.detach().float() * z.detach().float()).item())
            p.data.add_(z, alpha=float(scale))
    return math.sqrt(max(norm_sq, 0.0))


def _two_point_clean32(torch: Any, model: Any, batch: Dict[str, Any], params: Sequence[Tuple[str, Any]], seed: int, h: float) -> Tuple[float, float]:
    _add_direction(torch, params, seed, +float(h))
    fp = _loss(model, batch)
    _add_direction(torch, params, seed, -2.0 * float(h))
    fm = _loss(model, batch)
    _add_direction(torch, params, seed, +float(h))
    return float((fp - fm) / (2.0 * float(h))), float(fp - fm)


def _curvature_clean32(torch: Any, model: Any, batch: Dict[str, Any], params: Sequence[Tuple[str, Any]], seed: int, h2: float) -> Tuple[float, float]:
    f0 = _loss(model, batch)
    u_norm = _add_direction(torch, params, seed, +float(h2))
    f1 = _loss(model, batch)
    _add_direction(torch, params, seed, +float(h2))
    f2 = _loss(model, batch)
    _add_direction(torch, params, seed, -2.0 * float(h2))
    k = float((f2 - 2.0 * f1 + f0) / (float(h2) * float(h2)))
    lam = abs(k) / (u_norm * u_norm + 1e-30)
    return k, lam


def _scale_delta_rms_sqrt6(params: Sequence[Tuple[str, Any]], *, bits: int, group_size: int) -> Dict[str, Any]:
    import torch

    qmax = float((1 << (int(bits) - 1)) - 1)
    sum_sq = 0.0
    count = 0
    scale_min = None
    scale_max = None
    scale_samples = []
    for name, p in params:
        flat = p.detach().float().cpu().reshape(-1)
        n = int(flat.numel())
        if n == 0:
            continue
        for start in range(0, n, int(group_size)):
            chunk = flat[start:start + int(group_size)]
            c = int(chunk.numel())
            max_abs = float(torch.max(torch.abs(chunk)).item()) if c else 0.0
            scale = max_abs / qmax if max_abs > 0.0 and math.isfinite(max_abs) else 1.0 / qmax
            sum_sq += float(scale * scale * c)
            count += c
            scale_min = scale if scale_min is None else min(scale_min, scale)
            scale_max = scale if scale_max is None else max(scale_max, scale)
            if len(scale_samples) < 200000:
                scale_samples.append(scale)
    if count <= 0:
        raise ValueError("No trainable floating parameters found for INT8 scale estimate.")
    scale_rms = math.sqrt(sum_sq / float(count))
    delta = scale_rms / math.sqrt(6.0)
    arr = np.asarray(scale_samples, dtype=np.float64) if scale_samples else np.asarray([scale_rms], dtype=np.float64)
    return {
        "delta_mode": "int8_group_scale_coordinate_weighted_rms_over_sqrt6",
        "Delta": float(delta),
        "scale_rms": float(scale_rms),
        "scale_sample_median": float(np.median(arr)),
        "scale_sample_p90": float(np.quantile(arr, 0.90)),
        "scale_min_sampled": _safe_float(scale_min, 0.0),
        "scale_max_sampled": _safe_float(scale_max, 0.0),
        "num_coordinates": int(count),
        "bits": int(bits),
        "group_size": int(group_size),
    }


def simple2pt_corrected(args: argparse.Namespace) -> Dict[str, Any]:
    torch, *_ = _load_torch_stack()
    device = torch.device(args.device if args.device else ("cuda" if torch.cuda.is_available() else "cpu"))
    warnings: List[str] = []
    random.seed(int(args.seed))
    np.random.seed(int(args.seed))
    torch.manual_seed(int(args.seed))
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(int(args.seed))

    model, batch, params, _ = _make_batch(
        model_name=args.model,
        task=args.task,
        data_root=repo_path(args.data_root),
        k=int(args.k),
        seed=int(args.data_seed),
        dataset_mode=str(args.dataset_mode),
        batch_size=int(args.hstar_batch_size),
        device=device,
    )
    d_trainable = int(sum(p.numel() for _, p in params))
    delta_meta = _scale_delta_rms_sqrt6(params, bits=8, group_size=int(args.quantization_group_size))

    model.float()
    model.eval()

    g_rows = []
    g_values = []
    seeds_g = [int(args.seed) * 1000003 + 17 + i for i in range(max(1, int(args.hstar_num_g_dirs)))]
    for h in H_GRID_G:
        vals = []
        for seed in seeds_g:
            d2, loss_diff = _two_point_clean32(torch, model, batch, params, seed=seed, h=float(h))
            vals.append(abs(float(d2)))
        g_hat_h = math.sqrt(math.pi / 2.0) * float(np.mean(vals))
        g_values.append(g_hat_h)
        g_rows.append({"h_G": float(h), "G_abs": g_hat_h, "mean_abs_d2": float(np.mean(vals)), "num_dirs": len(vals)})
    G_hat = float(np.median(np.asarray(g_values, dtype=np.float64)))

    lams = []
    seeds_l = [int(args.seed) * 1000003 + 9001 + i for i in range(max(1, int(args.hstar_num_l_dirs)))]
    for seed in seeds_l:
        _, lam = _curvature_clean32(torch, model, batch, params, seed=seed, h2=float(args.hstar_l_h2))
        if math.isfinite(lam):
            lams.append(float(lam))
    if not lams:
        raise RuntimeError("No finite L estimates from clean32 curvature probes.")
    L_hat = float(np.quantile(np.asarray(lams, dtype=np.float64), 0.90))
    if L_hat <= 0.0 or not math.isfinite(L_hat):
        L_hat = float(np.median(np.asarray(lams, dtype=np.float64)))
        warnings.append("L_q90_nonpositive_or_nonfinite_used_median")
    if L_hat <= 0.0 or not math.isfinite(L_hat):
        raise RuntimeError("L estimate is invalid.")

    Delta = float(delta_meta["Delta"])
    denom = 16.0 * L_hat * L_hat * float(d_trainable) * float(d_trainable + 2)
    hstar = float(((Delta * Delta * G_hat * G_hat) / denom) ** 0.25)
    hstar = max(float(args.h_min), min(float(args.h_max), hstar))
    return {
        "h_policy": "ours",
        "h_value": hstar,
        "method": "simple2pt_corrected",
        "simple2pt_corrected": {
            "enabled": True,
            "Delta": Delta,
            "Delta_meta": delta_meta,
            "G_method": "clean32_absG_median_1e-4_3e-4_1e-3",
            "G_hat": G_hat,
            "G_candidates": g_rows,
            "L_method": "L_clean32_q90_fixed_h2",
            "L_hat": L_hat,
            "L_h2": float(args.hstar_l_h2),
            "L_lambda_q50": float(np.quantile(np.asarray(lams, dtype=np.float64), 0.50)),
            "L_lambda_q90": float(np.quantile(np.asarray(lams, dtype=np.float64), 0.90)),
            "L_num_dirs": len(lams),
            "d_trainable": d_trainable,
            "formula": "(Delta^2*G^2/(16*L^2*d*(d+2)))^(1/4)",
        },
        "warnings": warnings,
    }


def resolve_h_policy(args: argparse.Namespace) -> Dict[str, Any]:
    policy = str(args.h_policy).strip()
    if policy not in H_POLICIES:
        raise ValueError(f"Unsupported h_policy={policy}; expected {sorted(H_POLICIES)}")
    if policy != "ours":
        return fixed_policy_metadata(policy)
    try:
        return simple2pt_corrected(args)
    except Exception as exc:
        if not bool(args.allow_hstar_fallback):
            raise
        meta = fixed_policy_metadata("mezo_default")
        meta.update({
            "h_policy": "ours",
            "method": "simple2pt_corrected_fallback_to_1e-3",
            "simple2pt_corrected": {
                "enabled": True,
                "failed": True,
                "error": f"{type(exc).__name__}: {exc}",
                "fallback_h": 1e-3,
            },
            "warnings": [f"simple2pt_corrected_failed:{type(exc).__name__}"],
        })
        return meta


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--h_policy", required=True, choices=sorted(H_POLICIES))
    parser.add_argument("--task", default="SST-2")
    parser.add_argument("--model", default="roberta-large")
    parser.add_argument("--data_root", default="medium_models/data/k-shot-1k-test")
    parser.add_argument("--dataset_mode", choices=["full", "fewshot"], default="full")
    parser.add_argument("--k", type=int, default=16)
    parser.add_argument("--seed", type=int, default=16)
    parser.add_argument("--data_seed", type=int, default=16)
    parser.add_argument("--device", default="")
    parser.add_argument("--quantization_group_size", type=int, default=128)
    parser.add_argument("--hstar_batch_size", type=int, default=4)
    parser.add_argument("--hstar_num_g_dirs", type=int, default=int(os.environ.get("HSTAR_NUM_G_DIRS", "4")))
    parser.add_argument("--hstar_num_l_dirs", type=int, default=int(os.environ.get("HSTAR_NUM_L_DIRS", "4")))
    parser.add_argument("--hstar_l_h2", type=float, default=H_L_DEFAULT)
    parser.add_argument("--h_min", type=float, default=1e-6)
    parser.add_argument("--h_max", type=float, default=1e-1)
    parser.add_argument("--allow_hstar_fallback", action="store_true")
    parser.add_argument("--output_json", default="")
    return parser


def main(argv: Optional[Sequence[str]] = None) -> int:
    parser = build_arg_parser()
    args = parser.parse_args(argv)
    meta = resolve_h_policy(args)
    meta.update({
        "task": args.task,
        "model": args.model,
        "seed": int(args.seed),
        "data_seed": int(args.data_seed),
        "k": int(args.k),
        "dataset_mode": str(args.dataset_mode),
    })
    if args.output_json:
        path = Path(args.output_json)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(meta, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(meta, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
