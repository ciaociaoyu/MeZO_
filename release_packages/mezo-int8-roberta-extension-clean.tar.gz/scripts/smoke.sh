#!/bin/bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="${PROJECT_ROOT:-$(cd "${SCRIPT_DIR}/.." && pwd)}"
cd "${PROJECT_ROOT}"

SMOKE_STEPS="${SMOKE_STEPS:-10}"
SMOKE_EVAL_STEPS="${SMOKE_EVAL_STEPS:-5}"
SMOKE_BATCH_SIZE="${SMOKE_BATCH_SIZE:-4}"
SMOKE_PROBE_DIRS="${SMOKE_PROBE_DIRS:-2}"
SMOKE_TASK="${SMOKE_TASK:-SST-2}"
SMOKE_RUN_NAME="${SMOKE_RUN_NAME:-smoke_roberta_large_int8_${SMOKE_TASK}_ours_step${SMOKE_STEPS}}"
SMOKE_RESULT_ROOT="${SMOKE_RESULT_ROOT:-outputs/smoke}"

export DATALOADER_SHUFFLE=True
export HSTAR_BATCH_SIZE="${HSTAR_BATCH_SIZE:-2}"
export HSTAR_NUM_G_DIRS="${HSTAR_NUM_G_DIRS:-1}"
export HSTAR_NUM_L_DIRS="${HSTAR_NUM_L_DIRS:-1}"
export PROBE_EVERY=1
export NUM_PROBE_DIRECTIONS="${SMOKE_PROBE_DIRS}"

python scripts/run_int8_roberta.py \
  --task "${SMOKE_TASK}" \
  --h_policy ours \
  --steps "${SMOKE_STEPS}" \
  --eval_steps "${SMOKE_EVAL_STEPS}" \
  --batch_size "${SMOKE_BATCH_SIZE}" \
  --result_root "${SMOKE_RESULT_ROOT}" \
  --run_name "${SMOKE_RUN_NAME}" \
  --num_probe_directions "${SMOKE_PROBE_DIRS}" \
  --hstar_batch_size "${HSTAR_BATCH_SIZE}" \
  --hstar_num_g_dirs "${HSTAR_NUM_G_DIRS}" \
  --hstar_num_l_dirs "${HSTAR_NUM_L_DIRS}" \
  --allow_hstar_fallback

RUN_DIR="${PROJECT_ROOT}/${SMOKE_RESULT_ROOT}/${SMOKE_RUN_NAME}/seed16"
python scripts/validate_smoke_outputs.py --run_dir "${RUN_DIR}"
echo "Smoke OK: ${RUN_DIR}"
