#!/bin/bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="${PROJECT_ROOT:-$(cd "${SCRIPT_DIR}/.." && pwd)}"
cd "${PROJECT_ROOT}"

ENV_NAME="${ENV_NAME:-mezo-int8}"
PYTHON_VERSION="${PYTHON_VERSION:-3.10}"
SKIP_CONDA="${SKIP_CONDA:-0}"
SKIP_TORCH="${SKIP_TORCH:-0}"
SKIP_DATA="${SKIP_DATA:-0}"
TORCH_INDEX_URL="${TORCH_INDEX_URL:-https://download.pytorch.org/whl/cu121}"

if [[ "${SKIP_CONDA}" != "1" ]]; then
  if ! command -v conda >/dev/null 2>&1; then
    echo "conda not found. Install conda or rerun with SKIP_CONDA=1 inside an existing env." >&2
    exit 1
  fi
  if ! conda env list | awk '{print $1}' | grep -qx "${ENV_NAME}"; then
    conda create -y -n "${ENV_NAME}" "python=${PYTHON_VERSION}"
  fi
  # shellcheck disable=SC1091
  source "$(conda info --base)/etc/profile.d/conda.sh"
  conda activate "${ENV_NAME}"
fi

python -m pip install --upgrade pip
if [[ "${SKIP_TORCH}" != "1" ]]; then
  python -m pip install torch torchvision torchaudio --index-url "${TORCH_INDEX_URL}"
fi
python -m pip install -r requirements.txt

if [[ "${SKIP_DATA}" != "1" ]]; then
  (cd medium_models/data && bash download_dataset.sh)
  python medium_models/tools/generate_k_shot_data.py \
    --mode k-shot-1k-test \
    --dataset_mode full \
    --k 16 \
    --seed 16 \
    --task SST-2 RTE MNLI trec \
    --data_dir medium_models/data/original \
    --output_dir medium_models/data
fi

python - <<'PY'
import json, torch
print(json.dumps({
  "python_ok": True,
  "torch": torch.__version__,
  "cuda_available": torch.cuda.is_available(),
  "cuda_device": torch.cuda.get_device_name(0) if torch.cuda.is_available() else None,
}, indent=2))
PY
