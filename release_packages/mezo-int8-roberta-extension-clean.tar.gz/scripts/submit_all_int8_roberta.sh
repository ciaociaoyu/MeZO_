#!/bin/bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="${PROJECT_ROOT:-$(cd "${SCRIPT_DIR}/.." && pwd)}"
cd "${PROJECT_ROOT}"

MANIFEST="${MANIFEST:-configs/int8_roberta_extension_manifest.csv}"
MAX_CONCURRENT="${MAX_CONCURRENT:-7}"
ACCOUNT="${ACCOUNT:-}"
PARTITION="${PARTITION:-L4GPU}"
GPUS="${GPUS:-1}"
GRES="${GRES:-gpu:${GPUS}}"
TIME="${TIME:-24:00:00}"
CPUS_PER_TASK="${CPUS_PER_TASK:-8}"
MEM="${MEM:-64G}"
CONDA_ENV="${CONDA_ENV:-mezo-int8}"

if [[ "${MAX_CONCURRENT}" -gt 7 ]]; then
  echo "MAX_CONCURRENT=${MAX_CONCURRENT} exceeds the release cap; clamping to 7." >&2
  MAX_CONCURRENT=7
fi

python scripts/write_int8_manifest.py --output "${MANIFEST}" --dataset_mode full >/dev/null
N_ROWS=$(( $(wc -l < "${MANIFEST}") - 1 ))
if [[ "${N_ROWS}" -le 0 ]]; then
  echo "Empty manifest: ${MANIFEST}" >&2
  exit 1
fi

echo "Manifest: ${MANIFEST}"
echo "Rows: ${N_ROWS}"
echo "Array: 0-$((N_ROWS - 1))%${MAX_CONCURRENT}"
echo "Resources: account=${ACCOUNT:-<none>} partition=${PARTITION:-<default>} gres=${GRES} time=${TIME} cpus=${CPUS_PER_TASK} mem=${MEM}"
echo
column -s, -t < "${MANIFEST}" | sed -n '1,40p' || sed -n '1,40p' "${MANIFEST}"
echo

SBATCH_ARGS=(
  --array="0-$((N_ROWS - 1))%${MAX_CONCURRENT}"
  --gres="${GRES}"
  --time="${TIME}"
  --cpus-per-task="${CPUS_PER_TASK}"
  --mem="${MEM}"
  --export="ALL,PROJECT_ROOT=${PROJECT_ROOT},MANIFEST=${MANIFEST},CONDA_ENV=${CONDA_ENV},RESULT_ROOT=${RESULT_ROOT:-outputs/int8_roberta_full},PROBE_EVERY=${PROBE_EVERY:-1000},NUM_PROBE_DIRECTIONS=${NUM_PROBE_DIRECTIONS:-8},HSTAR_BATCH_SIZE=${HSTAR_BATCH_SIZE:-4},HSTAR_NUM_G_DIRS=${HSTAR_NUM_G_DIRS:-4},HSTAR_NUM_L_DIRS=${HSTAR_NUM_L_DIRS:-4},ALLOW_HSTAR_FALLBACK=${ALLOW_HSTAR_FALLBACK:-}"
)
if [[ -n "${ACCOUNT}" ]]; then
  SBATCH_ARGS+=(--account="${ACCOUNT}")
fi
if [[ -n "${PARTITION}" ]]; then
  SBATCH_ARGS+=(--partition="${PARTITION}")
fi

echo "Project root: ${PROJECT_ROOT}"
echo "sbatch ${SBATCH_ARGS[*]} scripts/slurm_int8_roberta_array.sbatch"
if [[ "${CONFIRM_SUBMIT:-0}" != "1" ]]; then
  echo "Dry run only. Set CONFIRM_SUBMIT=1 to submit."
  exit 0
fi

mkdir -p slurm_logs
sbatch "${SBATCH_ARGS[@]}" scripts/slurm_int8_roberta_array.sbatch
