#!/usr/bin/env python3
"""Run one INT8 RoBERTa MeZO job with a named h policy."""

from __future__ import annotations

import argparse
import csv
import json
import os
import subprocess
import sys
from pathlib import Path
from typing import Any, Dict, Iterable, Optional, Sequence

from compute_h_value import H_POLICIES, resolve_h_policy


def repo_root() -> Path:
    return Path(__file__).resolve().parents[1]


def repo_path(root: Path, path_value: str) -> Path:
    path = Path(path_value).expanduser()
    if path.is_absolute():
        return path
    return root / path


def h_label(value: float) -> str:
    text = f"{float(value):.8g}"
    return text.replace(".", "p").replace("-", "m")


def read_manifest(path: Path, index: int) -> Dict[str, str]:
    with path.open(newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    if index < 0 or index >= len(rows):
        raise IndexError(f"manifest index {index} out of range for {path} with {len(rows)} rows")
    return rows[index]


def coerce_bool_text(value: Any, default: str = "True") -> str:
    if value is None or str(value).strip() == "":
        return default
    return "True" if str(value).strip().lower() in {"1", "true", "yes", "y"} else "False"


def update_json(path: Path, updates: Dict[str, Any]) -> None:
    data: Dict[str, Any] = {}
    if path.exists():
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            data = {"_previous_parse_failed": True}
    data.update(updates)
    path.write_text(json.dumps(data, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def add_fields_to_jsonl(path: Path, fields: Dict[str, Any]) -> int:
    if not path.exists():
        return 0
    rows = []
    for line in path.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        try:
            row = json.loads(line)
        except Exception:
            continue
        row.update(fields)
        rows.append(row)
    if rows:
        path.write_text("".join(json.dumps(r, sort_keys=True) + "\n" for r in rows), encoding="utf-8")
    return len(rows)


def add_fields_to_csv(path: Path, fields: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    if not path.exists():
        return None
    with path.open(newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
        fieldnames = list(f.fieldnames or [])
    if not rows:
        return None
    for key in fields:
        if key not in fieldnames:
            fieldnames.append(key)
    for row in rows:
        for key, value in fields.items():
            row[key] = json.dumps(value, sort_keys=True) if isinstance(value, (dict, list)) else value
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)
    return rows[-1]


def parse_fd_true_nmse(run_dir: Path, probe_stats_rows: int) -> Optional[float]:
    candidates = [
        run_dir / "metrics_logs" / "zo_directional_probe.csv",
        run_dir / "zo_directional_probe.csv",
    ]
    for path in candidates:
        if not path.exists():
            continue
        with path.open(newline="", encoding="utf-8") as f:
            rows = list(csv.DictReader(f))
        for row in reversed(rows):
            value = row.get("fd_true_nmse") or row.get("nmse")
            if value not in (None, ""):
                try:
                    return float(value)
                except Exception:
                    pass
    # Fallback: compute from per-direction probe JSONL if d_true/d_fd lists exist.
    path = run_dir / "probe_stats.jsonl"
    if path.exists():
        vals = []
        denom = []
        for line in path.read_text(encoding="utf-8").splitlines():
            try:
                row = json.loads(line)
            except Exception:
                continue
            if row.get("fd_true_nmse") is not None:
                try:
                    return float(row["fd_true_nmse"])
                except Exception:
                    pass
            d_true = row.get("d_true_list")
            d_fd = row.get("d_fd_list")
            if isinstance(d_true, list) and isinstance(d_fd, list):
                for a, b in zip(d_true, d_fd):
                    try:
                        vals.append((float(b) - float(a)) ** 2)
                        denom.append(float(a) ** 2)
                    except Exception:
                        continue
        if vals and sum(denom) > 0:
            return float(sum(vals) / max(sum(denom), 1e-30))
    return None


def postprocess_run(run_dir: Path, h_meta: Dict[str, Any], command: Sequence[str], exit_code: int) -> None:
    simple = h_meta.get("simple2pt_corrected", {})
    fields = {
        "run_name": h_meta.get("run_name"),
        "task": h_meta.get("task"),
        "model": h_meta.get("model"),
        "seed": h_meta.get("seed"),
        "data_seed": h_meta.get("data_seed"),
        "dataset_mode": h_meta.get("dataset_mode"),
        "precision_mode": "int8",
        "zo_quantization": "int8",
        "quant_bits": 8,
        "quantization_algorithm": h_meta.get("quantization_algorithm"),
        "quantization_group_size": h_meta.get("quantization_group_size"),
        "update_backend": "fp16_master",
        "h_policy": h_meta.get("h_policy"),
        "h_value": h_meta.get("h_value"),
        "simple2pt_corrected": bool(simple.get("enabled", False)),
        "simple2pt_corrected_method": h_meta.get("method"),
        "simple2pt_corrected_hstar": h_meta.get("h_value") if h_meta.get("h_policy") == "ours" else None,
    }
    run_dir.mkdir(parents=True, exist_ok=True)
    (run_dir / "h_policy_metadata.json").write_text(json.dumps(h_meta, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    probe_rows = add_fields_to_jsonl(run_dir / "probe_stats.jsonl", fields)
    last_probe = add_fields_to_csv(run_dir / "metrics_logs" / "zo_directional_probe.csv", fields)
    fd_true_nmse = parse_fd_true_nmse(run_dir, probe_rows)
    probe_log_dir = run_dir / "metrics"
    probe_log_dir.mkdir(exist_ok=True)
    probe_payload = dict(fields)
    probe_payload.update({
        "fd_true_nmse": fd_true_nmse,
        "training_exit_code": int(exit_code),
        "source_probe_rows": int(probe_rows),
    })
    (probe_log_dir / "probe_h_policy.jsonl").write_text(json.dumps(probe_payload, sort_keys=True) + "\n", encoding="utf-8")

    common = {
        **fields,
        "fd_true_nmse": fd_true_nmse,
        "h_policy_metadata": h_meta,
        "training_command": list(command),
        "training_exit_code": int(exit_code),
    }
    update_json(run_dir / "run_metadata.json", common)
    update_json(run_dir / "run_summary.json", common)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", default="")
    parser.add_argument("--manifest-index", type=int, default=None)
    parser.add_argument("--task", default="SST-2")
    parser.add_argument("--h_policy", choices=sorted(H_POLICIES), default="mezo_default")
    parser.add_argument("--model", default="roberta-large")
    parser.add_argument("--k", type=int, default=16)
    parser.add_argument("--dataset_mode", choices=["full", "fewshot"], default="full")
    parser.add_argument("--seed", type=int, default=16)
    parser.add_argument("--data_seed", type=int, default=16)
    parser.add_argument("--steps", type=int, default=20000)
    parser.add_argument("--eval_steps", type=int, default=1000)
    parser.add_argument("--batch_size", type=int, default=64)
    parser.add_argument("--learning_rate", default="1e-6")
    parser.add_argument("--result_root", default="outputs/int8_roberta_full")
    parser.add_argument("--run_name", default="")
    parser.add_argument("--data_root", default="medium_models/data/k-shot-1k-test")
    parser.add_argument("--quantization_algorithm", default="groupwise_symmetric")
    parser.add_argument("--quantization_group_size", type=int, default=128)
    parser.add_argument("--probe_every", type=int, default=int(os.environ.get("PROBE_EVERY", "1000")))
    parser.add_argument("--num_probe_directions", type=int, default=int(os.environ.get("NUM_PROBE_DIRECTIONS", "8")))
    parser.add_argument("--hstar_batch_size", type=int, default=int(os.environ.get("HSTAR_BATCH_SIZE", "4")))
    parser.add_argument("--hstar_num_g_dirs", type=int, default=int(os.environ.get("HSTAR_NUM_G_DIRS", "4")))
    parser.add_argument("--hstar_num_l_dirs", type=int, default=int(os.environ.get("HSTAR_NUM_L_DIRS", "4")))
    parser.add_argument("--allow_hstar_fallback", action="store_true")
    parser.add_argument("--dry_run", action="store_true")
    parser.add_argument("extra_args", nargs=argparse.REMAINDER)
    return parser


def main(argv: Optional[Sequence[str]] = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    root = repo_root()

    if args.manifest:
        row = read_manifest(root / args.manifest if not Path(args.manifest).is_absolute() else Path(args.manifest), int(args.manifest_index or 0))
        for key, value in row.items():
            if hasattr(args, key) and value not in (None, ""):
                current = getattr(args, key)
                if isinstance(current, int):
                    setattr(args, key, int(float(value)))
                else:
                    setattr(args, key, value)

    mode_tag = "full" if str(args.dataset_mode).lower() == "full" else f"k{args.k}"
    run_name = args.run_name or f"roberta_large_int8_{args.task}_{mode_tag}_seed{args.seed}_{args.h_policy}_step{args.steps}"
    result_root = repo_path(root, args.result_root)
    run_dir = result_root / run_name / f"seed{args.seed}"
    data_root = repo_path(root, args.data_root)

    h_args = argparse.Namespace(
        h_policy=args.h_policy,
        task=args.task,
        model=args.model,
        data_root=str(data_root),
        k=int(args.k),
        seed=int(args.seed),
        data_seed=int(args.data_seed),
        dataset_mode=str(args.dataset_mode),
        device="",
        quantization_group_size=int(args.quantization_group_size),
        hstar_batch_size=int(args.hstar_batch_size),
        hstar_num_g_dirs=int(args.hstar_num_g_dirs),
        hstar_num_l_dirs=int(args.hstar_num_l_dirs),
        hstar_l_h2=1e-3,
        h_min=1e-6,
        h_max=1e-1,
        allow_hstar_fallback=bool(args.allow_hstar_fallback),
    )
    h_meta = resolve_h_policy(h_args)
    h_meta.update({
        "run_name": run_name,
        "task": args.task,
        "model": args.model,
        "seed": int(args.seed),
        "data_seed": int(args.data_seed),
        "dataset_mode": str(args.dataset_mode),
        "precision_mode": "int8",
        "zo_quantization": "int8",
        "quant_bits": 8,
        "quantization_algorithm": str(args.quantization_algorithm),
        "quantization_group_size": int(args.quantization_group_size),
        "update_backend": "fp16_master",
    })
    h_value = float(h_meta["h_value"])
    run_dir.mkdir(parents=True, exist_ok=True)
    if not args.dry_run:
        for stale_rel in [
            "probe_stats.jsonl",
            "metrics_logs/zo_directional_probe.csv",
            "metrics/probe_h_policy.jsonl",
        ]:
            stale_path = run_dir / stale_rel
            if stale_path.exists():
                stale_path.unlink()
    (run_dir / "h_policy_metadata.json").write_text(json.dumps(h_meta, indent=2, sort_keys=True) + "\n", encoding="utf-8")

    medium = root / "medium_models"
    result_root_arg = os.path.relpath(result_root, medium)
    data_root_arg = os.path.relpath(data_root, medium)
    env = os.environ.copy()
    env.update({
        "TASK": str(args.task),
        "K": str(args.k),
        "SEED": str(args.seed),
        "DATA_SEED": str(args.data_seed),
        "DATASET_MODE": str(args.dataset_mode),
        "DATA_ROOT": data_root_arg,
        "BS": str(args.batch_size),
        "LR": str(args.learning_rate),
        "EPS": str(h_value),
        "STEP": str(args.steps),
        "EVAL_STEP": str(args.eval_steps),
        "MODEL": str(args.model),
        "USE_H": "False",
        "USE_C": "False",
        "DATALOADER_SHUFFLE": "True",
        "ZERO_ORDER_USE_TRAINER_OPTIM": "False",
        "EFFICIENT_ZERO_ORDER": "True",
        "KEEP_CHECKPOINTS": env.get("KEEP_CHECKPOINTS", "False"),
        "RESULT_ROOT": result_root_arg,
        "JOB_NAME": run_name,
        "TAG": f"{mode_tag}-{args.model}-int8-{args.h_policy}",
        "EXTRA_TAG": f"int8-{args.h_policy}",
    })

    cmd = [
        "bash",
        "mezo.sh",
        "--precision_mode", "int8",
        "--quant_bits", "8",
        "--zo_quantization", "int8",
        "--quantization_algorithm", str(args.quantization_algorithm),
        "--quantization_group_size", str(args.quantization_group_size),
        "--zo_update_backend", "fp16_master",
        "--zo_h", str(h_value),
        "--h_schedule", "fixed",
        "--probe_window_h_list", str(h_value),
        "--save_probe_stats_jsonl", "probe_stats.jsonl",
        "--zo_probe_every", str(args.probe_every),
        "--zo_probe_num_seeds", str(args.num_probe_directions),
        "--compute_true_grad_directional", "True",
        "--random_prediction_guard_enabled", "False",
        "--zo_probe_health_guard_enabled", "False",
    ]
    if args.extra_args:
        extra = args.extra_args[1:] if args.extra_args and args.extra_args[0] == "--" else args.extra_args
        cmd.extend(extra)

    print(json.dumps({"run_name": run_name, "run_dir": str(run_dir.relative_to(root)), "h_meta": h_meta, "cmd": cmd}, indent=2))
    if args.dry_run:
        postprocess_run(run_dir, h_meta, cmd, exit_code=0)
        return 0

    proc = subprocess.run(cmd, cwd=str(medium), env=env)
    postprocess_run(run_dir, h_meta, cmd, exit_code=int(proc.returncode))
    return int(proc.returncode)


if __name__ == "__main__":
    raise SystemExit(main())
