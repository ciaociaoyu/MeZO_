# Residual Grid Consistency Key Results

This package contains the compact residual-grid debug and 50-step short-run results from May 12, 2026. It intentionally excludes the full raw `per_layer_update_stats.jsonl` files because those are about 53 MB uncompressed across the three residual runs; the final-step per-layer extract is included instead.

## Source Directories

- Debug source: `/scratch/jy03364/MeZO_/runs/int8_residual_consistency_20260512_185856/debug/`
- Short-run source: `/scratch/jy03364/MeZO_/runs/int8_residual_consistency_20260512_190000/`

## Contents

- `summary.csv` and `summary.md`: run-level 50-step summary.
- `debug/scale_stats.csv`: trainable quantized parameter scale sanity.
- `debug/synthetic_residual_test.json`: synthetic residual equation tests.
- `debug/noop_update_check.csv`: no-op residual update check.
- `debug/one_step_equation_check.csv`: real-model one-step expected-vs-actual check.
- `update_stats/*_update_stats.jsonl`: compact global update stats for each run.
- `diagnostics/per_layer_last_step.csv`: final-step per-layer diagnostics extracted from large JSONL logs.
- `diagnostics/scale_drift_summary.csv`: scale-drift maxima; all are zero for residual-grid runs.
- `diagnostics/scale_drift_last_step.csv`: final-step per-layer scale drift.

## Diagnosis

The residual-over-scale anomaly was caused by initializing/freeze-snapshotting residual-grid scales after finite-difference perturb/reset had introduced tiny numerical noise into zero-valued trainable tensors, producing scales around `1e-12` in layers such as `classifier.bias`, `roberta.embeddings.token_type_embeddings.weight`, and `roberta.pooler.dense.bias`. The updater is now initialized before perturbation when residual-grid is active, and residual-over-scale quantiles are computed over unsaturated coordinates.

After the fix, no-op updates are inactive, the synthetic residual test passes, the real one-step integer equation check matches exactly (`max_abs_q_diff=0`), scale drift is zero, and round/max_step=0 has zero unsaturated residual-bound violations.
