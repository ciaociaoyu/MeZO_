#!/usr/bin/env bash
set -euo pipefail
source "$HOME/miniconda3/etc/profile.d/conda.sh"
conda activate ciao
ROOT=/scratch/jy03364/MeZO_/runs/window_training_small_20260512_201024
mkdir -p "$ROOT/logs"
nvidia-smi > "$ROOT/nvidia_smi_start.txt"
run_one() {
  local name="$1" precision="$2" h="$3" direction="$4" sparse_rate="$5" sparse_mode="$6" sparse_rescale="$7" backend="$8"
  (
    cd /scratch/jy03364/MeZO_/medium_models
    TASK=SST-5 K=16 SEED=16 DATA_SEED=16 DATASET_MODE=full FULL_DEV_RATIO=0.1 BS=64 LR=1e-5 EPS="$h" WD=0 STEP=300 EVAL_STEP=50 MODEL=roberta-large USE_H=False USE_C=False DATALOADER_SHUFFLE=False EFFICIENT_ZERO_ORDER=True EXTRA_TAG=window-training CUDA_VISIBLE_DEVICES=0 TOKENIZERS_PARALLELISM=false \
      bash ./mezo.sh \
        --result_root "$ROOT" \
        --job_name "$name" \
        --dataset_mode full \
        --precision_mode "$precision" \
        --zo_h "$h" \
        --direction_type "$direction" \
        --sparse_rate "$sparse_rate" \
        --sparse_mode "$sparse_mode" \
        --sparse_rescale "$sparse_rescale" \
        --zo_update_backend "$backend" \
        --random_prediction_guard_enabled False \
        --save_strategy no \
        --save_at_last False \
        --no_predict
  ) > "$ROOT/logs/${name}.log" 2>&1
}
run_one dense_fp32_h1e-5 fp32 1e-5 dense 1.0 none none direct_int8
run_one dense_fp32_h1e-3 fp32 1e-3 dense 1.0 none none direct_int8
run_one dense_fp32_h1e-2 fp32 1e-2 dense 1.0 none none direct_int8
run_one dense_bf16_h1e-5 bf16 1e-5 dense 1.0 none none direct_int8
run_one dense_bf16_h1e-3 bf16 1e-3 dense 1.0 none none direct_int8
run_one dense_bf16_h1e-2 bf16 1e-2 dense 1.0 none none direct_int8
run_one dense_int8_fp16master_h3e-4 int8 3e-4 dense 1.0 none none fp16_master
run_one dense_int8_fp16master_h3e-3 int8 3e-3 dense 1.0 none none fp16_master
run_one dense_int8_fp16master_h1e-2 int8 1e-2 dense 1.0 none none fp16_master
run_one sparse_int8_fp16master_p0p01_h0p0012 int8 0.0012 sparse 0.01 bernoulli inv_sqrt_p fp16_master
run_one sparse_int8_fp16master_p0p003_h0p0003286 int8 0.0003286335345030997 sparse 0.003 bernoulli inv_sqrt_p fp16_master
python /scratch/jy03364/MeZO_/scripts/summarize_window_training.py "$ROOT" > "$ROOT/logs/summary.log" 2>&1
