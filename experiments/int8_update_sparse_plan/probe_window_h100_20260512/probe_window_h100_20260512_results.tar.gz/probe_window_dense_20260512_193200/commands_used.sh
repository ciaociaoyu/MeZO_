#!/usr/bin/env bash
set -euo pipefail
source "$HOME/miniconda3/etc/profile.d/conda.sh"
conda activate ciao
ROOT=/scratch/jy03364/MeZO_/runs/probe_window_dense_20260512_193200
HLIST='1e-5,3e-5,1e-4,3e-4,1e-3,1.5e-3,2e-3,3e-3,4e-3,5e-3,1e-2'
mkdir -p "$ROOT/logs"
for P in fp32 bf16 int8; do
  CUDA_VISIBLE_DEVICES=0 python scripts/probe_h_window_diagnostic.py \
    --precision_mode "$P" \
    --h_list "$HLIST" \
    --num_probe_directions 50 \
    --num_probe_batches 1 \
    --direction_type dense \
    --output_dir "$ROOT/${P}_dense" \
    --compute_true_grad_directional true \
    > "$ROOT/logs/${P}_dense.log" 2>&1
done
python scripts/summarize_probe_window.py "$ROOT" > "$ROOT/logs/summary.log" 2>&1
