#!/usr/bin/env bash
set -euo pipefail
source "$HOME/miniconda3/etc/profile.d/conda.sh"
conda activate ciao
ROOT=/scratch/jy03364/MeZO_/runs/probe_window_sparse_20260512_194300
mkdir -p "$ROOT/logs"
for SPEC in \
  '0.1:0.00023717082451262845,0.0004743416490252569,0.0009486832980505138,0.0018973665961010276,0.003794733192202055,0.00758946638440411' \
  '0.03:0.0001299038105676658,0.0002598076211353316,0.0005196152422706632,0.0010392304845413265,0.002078460969082653,0.004156921938165306' \
  '0.01:0.000075,0.00015,0.0003,0.0006,0.0012,0.0024' \
  '0.003:0.00004107919181288746,0.00008215838362577492,0.00016431676725154984,0.0003286335345030997,0.0006572670690061994,0.0013145341380123988'; do
  P="${SPEC%%:*}"
  HLIST="${SPEC#*:}"
  SAFE="p${P//./p}"
  CUDA_VISIBLE_DEVICES=0 python scripts/probe_h_window_diagnostic.py \
    --precision_mode int8 \
    --h_list "$HLIST" \
    --num_probe_directions 50 \
    --num_probe_batches 1 \
    --direction_type sparse \
    --sparse_rate "$P" \
    --sparse_mode bernoulli \
    --sparse_rescale inv_sqrt_p \
    --output_dir "$ROOT/${SAFE}_int8_sparse" \
    --compute_true_grad_directional true \
    > "$ROOT/logs/${SAFE}_int8_sparse.log" 2>&1
done
python scripts/summarize_probe_window.py "$ROOT" > "$ROOT/logs/summary.log" 2>&1
